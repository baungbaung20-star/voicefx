extends RefCounted
## WAV reading / writing. Safe to call from a worker thread (no scene-tree access).
## Reads PCM 8/16/24/32-bit and float 32/64-bit (also WAVE_FORMAT_EXTENSIBLE).
## Writes 16-bit PCM (mono or stereo).

const AudioDoc = preload("res://scripts/audio_doc.gd")

const INV16 := 1.0 / 32768.0

enum Kind { U8, S16, S24, S32, F32, F64, ALAW, ULAW }

static var _dec_alaw := PackedFloat32Array()
static var _dec_ulaw := PackedFloat32Array()
static var _enc_alaw := PackedByteArray()
static var _enc_ulaw := PackedByteArray()


static func read_all(path: String) -> PackedByteArray:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return PackedByteArray()
	var flen := f.get_length()
	var out := PackedByteArray()
	if flen > 0:
		out = f.get_buffer(flen)
	else:
		while not f.eof_reached():
			var chunk := f.get_buffer(1 << 20)
			if chunk.is_empty():
				break
			out.append_array(chunk)
	return out


static func _sample(data: PackedByteArray, o: int, kind: int) -> float:
	match kind:
		Kind.U8:
			return (float(data[o]) - 128.0) / 128.0
		Kind.S16:
			return data.decode_s16(o) * INV16
		Kind.S24:
			var v := data[o] | (data[o + 1] << 8) | (data[o + 2] << 16)
			if v >= 0x800000:
				v -= 0x1000000
			return float(v) / 8388608.0
		Kind.S32:
			return float(data.decode_s32(o)) / 2147483648.0
		Kind.F32:
			return data.decode_float(o)
		Kind.ALAW:
			return _dec_alaw[data[o]]
		Kind.ULAW:
			return _dec_ulaw[data[o]]
		_:
			return data.decode_double(o)


## Returns { ok: bool, error: String, doc: AudioDoc }
@warning_ignore("integer_division")
static func parse_wav(path: String, progress: Callable = Callable()) -> Dictionary:
	var data := read_all(path)
	if data.size() < 44:
		return {"ok": false, "error": "Cannot read file (%s)" % error_string(FileAccess.get_open_error())}
	var riff := data.slice(0, 4).get_string_from_ascii()
	if (riff != "RIFF" and riff != "RF64") or data.slice(8, 12).get_string_from_ascii() != "WAVE":
		return {"ok": false, "error": "Not a WAV file"}

	var pos := 12
	var have_fmt := false
	var tag := 0
	var chn := 0
	var rate := 0
	var bits := 0
	var data_off := -1
	var data_len := 0
	while pos + 8 <= data.size():
		var id := data.slice(pos, pos + 4).get_string_from_ascii()
		var sz := data.decode_u32(pos + 4)
		var body := pos + 8
		if id == "fmt " and body + 16 <= data.size():
			tag = data.decode_u16(body)
			chn = data.decode_u16(body + 2)
			rate = data.decode_u32(body + 4)
			bits = data.decode_u16(body + 14)
			if tag == 0xFFFE and sz >= 26 and body + 26 <= data.size():
				tag = data.decode_u16(body + 24)
			have_fmt = true
		elif id == "data":
			data_off = body
			if sz == 0xFFFFFFFF or body + sz > data.size():
				sz = data.size() - body
			data_len = sz
			break
		pos = body + sz + (sz & 1)

	if not have_fmt:
		return {"ok": false, "error": "WAV has no fmt chunk"}
	if data_off < 0:
		return {"ok": false, "error": "WAV has no audio data"}
	if chn < 1 or rate < 1000:
		return {"ok": false, "error": "Invalid WAV header"}

	var kind := -1
	if tag == 1:
		match bits:
			8: kind = Kind.U8
			16: kind = Kind.S16
			24: kind = Kind.S24
			32: kind = Kind.S32
	elif tag == 3:
		match bits:
			32: kind = Kind.F32
			64: kind = Kind.F64
	elif tag == 6 and bits == 8:
		kind = Kind.ALAW
		_ensure_law_tables()
	elif tag == 7 and bits == 8:
		kind = Kind.ULAW
		_ensure_law_tables()
	if kind < 0:
		return {"ok": false, "error": "Unsupported WAV (format %d, %d-bit)" % [tag, bits]}

	var bps := bits / 8
	var frame_bytes := chn * bps
	var frames := data_len / frame_bytes
	if frames < 1:
		return {"ok": false, "error": "WAV is empty"}

	var l := PackedFloat32Array()
	var r := PackedFloat32Array()
	l.resize(frames)
	var stereo := chn > 1
	if stereo:
		r.resize(frames)
	var o := data_off
	var report := 1 << 18
	if kind == Kind.S16:
		if stereo:
			for i in frames:
				l[i] = data.decode_s16(o) * INV16
				r[i] = data.decode_s16(o + 2) * INV16
				o += frame_bytes
				if (i & 0x3FFFF) == 0 and progress.is_valid():
					progress.call(0.5 * float(i) / float(frames))
		else:
			for i in frames:
				l[i] = data.decode_s16(o) * INV16
				o += 2
				if (i & 0x3FFFF) == 0 and progress.is_valid():
					progress.call(0.5 * float(i) / float(frames))
	else:
		for i in frames:
			l[i] = _sample(data, o, kind)
			if stereo:
				r[i] = _sample(data, o + bps, kind)
			o += frame_bytes
			if (i & 0x3FFFF) == 0 and progress.is_valid():
				progress.call(0.5 * float(i) / float(frames))
	if not stereo:
		r = l

	var doc := AudioDoc.new()
	doc.rate = rate
	doc.left = l
	doc.right = r
	doc.is_mono = not stereo
	doc.src_bits = bits
	doc.src_tag = tag
	doc.name = path.get_file().get_basename()
	if doc.name == "":
		doc.name = "audio"
	doc.build_peaks(progress, 0.5, 1.0)
	return {"ok": true, "error": "", "doc": doc}


# ------------------------------------------------------------------ G.711 (mu-law / A-law)

static func _alaw_to_lin(av: int) -> int:
	av ^= 0x55
	var t := (av & 0x0F) << 4
	var seg := (av & 0x70) >> 4
	match seg:
		0:
			t += 8
		1:
			t += 0x108
		_:
			t += 0x108
			t <<= seg - 1
	return t if (av & 0x80) != 0 else -t


static func _ulaw_to_lin(uv: int) -> int:
	uv = ~uv & 0xFF
	var t := ((uv & 0x0F) << 3) + 0x84
	t <<= (uv & 0x70) >> 4
	return (0x84 - t) if (uv & 0x80) != 0 else (t - 0x84)


static func _lin_to_alaw(pcm: int) -> int:
	var mask := 0
	pcm >>= 3
	if pcm >= 0:
		mask = 0xD5
	else:
		mask = 0x55
		pcm = -pcm - 1
	var ends := [0x1F, 0x3F, 0x7F, 0xFF, 0x1FF, 0x3FF, 0x7FF, 0xFFF]
	var seg := 0
	while seg < 8 and pcm > int(ends[seg]):
		seg += 1
	if seg >= 8:
		return 0x7F ^ mask
	var aval := seg << 4
	if seg < 2:
		aval |= (pcm >> 1) & 0x0F
	else:
		aval |= (pcm >> seg) & 0x0F
	return aval ^ mask


static func _lin_to_ulaw(pcm: int) -> int:
	var mask := 0
	pcm >>= 2
	if pcm < 0:
		pcm = -pcm
		mask = 0x7F
	else:
		mask = 0xFF
	if pcm > 8159:
		pcm = 8159
	pcm += 0x21
	var ends := [0x3F, 0x7F, 0xFF, 0x1FF, 0x3FF, 0x7FF, 0xFFF, 0x1FFF]
	var seg := 0
	while seg < 8 and pcm > int(ends[seg]):
		seg += 1
	if seg >= 8:
		return 0x7F ^ mask
	var uval := (seg << 4) | ((pcm >> (seg + 1)) & 0x0F)
	return uval ^ mask


static func _ensure_law_tables() -> void:
	if _dec_alaw.size() == 256:
		return
	_dec_alaw.resize(256)
	_dec_ulaw.resize(256)
	for i in 256:
		_dec_alaw[i] = float(_alaw_to_lin(i)) / 32768.0
		_dec_ulaw[i] = float(_ulaw_to_lin(i)) / 32768.0


static func _ensure_law_encoders() -> void:
	if _enc_alaw.size() == 65536:
		return
	_enc_alaw.resize(65536)
	_enc_ulaw.resize(65536)
	for i in 65536:
		_enc_alaw[i] = _lin_to_alaw(i - 32768)
		_enc_ulaw[i] = _lin_to_ulaw(i - 32768)


# ------------------------------------------------------------------ writing

## Encodes channels to raw sample bytes. tag: 1 PCM, 3 float, 6 A-law, 7 mu-law.
static func _encode(l: PackedFloat32Array, r: PackedFloat32Array, stereo: bool, tag: int, bits: int, progress: Callable, p0: float, p1: float) -> PackedByteArray:
	var n := l.size()
	var chn := 2 if stereo else 1
	var bps := bits / 8
	var bytes := PackedByteArray()
	bytes.resize(n * chn * bps)
	var span := (p1 - p0) / float(chn)
	_encode_channel(bytes, l, 0, chn * bps, tag, bits, progress, p0, p0 + span)
	if stereo:
		_encode_channel(bytes, r, bps, chn * bps, tag, bits, progress, p0 + span, p1)
	return bytes


static func _encode_channel(bytes: PackedByteArray, src: PackedFloat32Array, start: int, stride: int, tag: int, bits: int, progress: Callable, p0: float, p1: float) -> void:
	var n := src.size()
	var o := start
	var rep := progress.is_valid()
	if tag == 6:
		_ensure_law_encoders()
		for i in n:
			bytes[o] = _enc_alaw[roundi(clampf(src[i], -1.0, 1.0) * 32767.0) + 32768]
			o += stride
			if rep and (i & 0x3FFFF) == 0:
				progress.call(p0 + (p1 - p0) * float(i) / float(n))
	elif tag == 7:
		_ensure_law_encoders()
		for i in n:
			bytes[o] = _enc_ulaw[roundi(clampf(src[i], -1.0, 1.0) * 32767.0) + 32768]
			o += stride
			if rep and (i & 0x3FFFF) == 0:
				progress.call(p0 + (p1 - p0) * float(i) / float(n))
	elif tag == 3 and bits == 64:
		for i in n:
			bytes.encode_double(o, src[i])
			o += stride
			if rep and (i & 0x3FFFF) == 0:
				progress.call(p0 + (p1 - p0) * float(i) / float(n))
	elif tag == 3:
		for i in n:
			bytes.encode_float(o, src[i])
			o += stride
			if rep and (i & 0x3FFFF) == 0:
				progress.call(p0 + (p1 - p0) * float(i) / float(n))
	elif bits == 8:
		for i in n:
			bytes[o] = clampi(roundi(clampf(src[i], -1.0, 1.0) * 127.0) + 128, 0, 255)
			o += stride
			if rep and (i & 0x3FFFF) == 0:
				progress.call(p0 + (p1 - p0) * float(i) / float(n))
	elif bits == 24:
		for i in n:
			var iv := roundi(clampf(src[i], -1.0, 1.0) * 8388607.0)
			if iv < 0:
				iv += 0x1000000
			bytes[o] = iv & 0xFF
			bytes[o + 1] = (iv >> 8) & 0xFF
			bytes[o + 2] = (iv >> 16) & 0xFF
			o += stride
			if rep and (i & 0x3FFFF) == 0:
				progress.call(p0 + (p1 - p0) * float(i) / float(n))
	elif bits == 32:
		for i in n:
			bytes.encode_s32(o, roundi(clampf(src[i], -1.0, 1.0) * 2147483647.0))
			o += stride
			if rep and (i & 0x3FFFF) == 0:
				progress.call(p0 + (p1 - p0) * float(i) / float(n))
	else:
		for i in n:
			bytes.encode_s16(o, roundi(clampf(src[i], -1.0, 1.0) * 32767.0))
			o += stride
			if rep and (i & 0x3FFFF) == 0:
				progress.call(p0 + (p1 - p0) * float(i) / float(n))


## Converts channel layout / sample rate and writes a WAV with the chosen attributes.
## fmt: { tag:int (1,3,6,7), bits:int, channels:int (1|2), rate:int, aa:bool }
## Returns "" on success, otherwise an error message.
static func write_wav_fmt(path: String, doc, fmt: Dictionary, progress: Callable = Callable()) -> String:
	var n_in: int = doc.length()
	if n_in < 1:
		return "Nothing to save"
	var tag: int = fmt.get("tag", 1)
	var bits: int = fmt.get("bits", 16)
	if tag == 6 or tag == 7:
		bits = 8
	var chn: int = fmt.get("channels", 1 if doc.is_mono else 2)
	var rate_out: int = fmt.get("rate", doc.rate)
	var aa: bool = fmt.get("aa", true)
	var stereo := chn == 2
	var src_l: PackedFloat32Array = doc.left
	var src_r: PackedFloat32Array = doc.right
	var same: bool = doc.is_mono or not stereo   # both output channels carry identical data

	# 1) channel layout
	var out_l: PackedFloat32Array = src_l
	var out_r: PackedFloat32Array = src_l
	if not doc.is_mono:
		if stereo:
			out_r = src_r
		else:
			var mix := PackedFloat32Array()
			mix.resize(n_in)
			for i in n_in:
				mix[i] = (src_l[i] + src_r[i]) * 0.5
			out_l = mix
			out_r = mix
	# 2) sample rate
	var enc_p0 := 0.0
	if rate_out != doc.rate:
		var rs_end := 0.45 if same else 0.7
		if same:
			out_l = AudioDoc.resample(out_l, doc.rate, rate_out, aa, progress, 0.0, rs_end)
			out_r = out_l
		else:
			# left and right are converted in parallel (two threads)
			var th := Thread.new()
			th.start(AudioDoc.resample.bind(out_r, doc.rate, rate_out, aa))
			out_l = AudioDoc.resample(out_l, doc.rate, rate_out, aa, progress, 0.0, rs_end)
			out_r = th.wait_to_finish()
		enc_p0 = rs_end
	# 3) encode
	var bytes := _encode(out_l, out_r, stereo, tag, bits, progress, enc_p0, 0.95)

	# 4) header + write
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return "Cannot write file (%s)" % error_string(FileAccess.get_open_error())
	var frames := out_l.size()
	var bps := bits / 8
	var data_len := bytes.size()
	var pad := data_len & 1
	var plain_pcm := tag == 1
	var fmt_size := 16 if plain_pcm else 18
	var riff_size := 4 + (8 + fmt_size) + (0 if plain_pcm else 12) + 8 + data_len + pad
	f.store_buffer("RIFF".to_ascii_buffer())
	f.store_32(riff_size)
	f.store_buffer("WAVE".to_ascii_buffer())
	f.store_buffer("fmt ".to_ascii_buffer())
	f.store_32(fmt_size)
	f.store_16(tag)
	f.store_16(chn)
	f.store_32(rate_out)
	f.store_32(rate_out * chn * bps)
	f.store_16(chn * bps)
	f.store_16(bits)
	if not plain_pcm:
		f.store_16(0)
		f.store_buffer("fact".to_ascii_buffer())
		f.store_32(4)
		f.store_32(frames)
	f.store_buffer("data".to_ascii_buffer())
	f.store_32(data_len)
	f.store_buffer(bytes)
	if pad == 1:
		f.store_8(0)
	f.flush()
	var err := f.get_error()
	f.close()
	if progress.is_valid():
		progress.call(1.0)
	if err != OK:
		return "Write failed (%s)" % error_string(err)
	return ""


## Convenience: 16-bit PCM, same rate, same channel layout.
static func write_wav(path: String, doc, progress: Callable = Callable()) -> String:
	return write_wav_fmt(path, doc, {"tag": 1, "bits": 16, "channels": 1 if doc.is_mono else 2, "rate": doc.rate, "aa": false}, progress)


## A 4-second stereo test tone, so the editor can be tried without any file.
static func make_demo():
	var rate := 44100
	var n := rate * 4
	var l := PackedFloat32Array()
	var r := PackedFloat32Array()
	l.resize(n)
	r.resize(n)
	for i in n:
		var t := float(i) / float(rate)
		var env_l := 0.15 + 0.75 * absf(sin(t * PI * 0.75))
		var env_r := 0.15 + 0.75 * absf(sin(t * PI * 1.1 + 0.8))
		l[i] = env_l * (0.7 * sin(TAU * 220.0 * t) + 0.25 * sin(TAU * 440.0 * t))
		r[i] = env_r * (0.7 * sin(TAU * 330.0 * t) + 0.25 * sin(TAU * 660.0 * t))
		if i > rate * 3 and i < rate * 3 + 800:
			l[i] = 0.98
			r[i] = -0.98
	var d := AudioDoc.new()
	d.rate = rate
	d.left = l
	d.right = r
	d.is_mono = false
	d.name = "demo_tone"
	d.build_peaks()
	return d
