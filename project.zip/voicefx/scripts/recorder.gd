extends Node
## Plain microphone recorder (no effects, no monitoring).
## Mic -> AudioStreamPlayer on a private bus -> AudioEffectCapture (first effect)
## -> Amplify -80 dB (so nothing is heard on the speaker, no feedback).

const AudioDoc = preload("res://scripts/audio_doc.gd")

signal updated(peak: float)
signal limit_reached
signal no_audio

const BUS := "VFXRecord"
const MAX_SEC := 1200.0   # 20 minutes safety limit (RAM)
const NATIVE_MAX_SEC := 600.0   # native take can be stereo at a high rate -> 10 minutes

var recording := false
var doc = null

## Native Android recorder (plugin "VfxRecorder", AudioRecord). Only exists in a Gradle-built APK.
var use_native := true
var native_rate := 48000
var native_channels := 2
var native_source := 0      # 0 mic, 1 unprocessed, 2 voice recognition, 3 camcorder
var native_active := false  # true while the current take uses the native recorder
var channels := 1           # channels of the current take
var note := ""              # why the native recorder was not used (empty when fine)
var native_override = null  # tests can inject a fake plugin object here

var _native = null
var _nr := PackedFloat32Array()

var _capture: AudioEffectCapture
var _mic: AudioStreamPlayer
var _t0 := 0
var _total := 0
var _warned := false


func _ready() -> void:
	var idx := AudioServer.get_bus_index(BUS)
	if idx == -1:
		AudioServer.add_bus()
		idx = AudioServer.bus_count - 1
		AudioServer.set_bus_name(idx, BUS)
		_capture = AudioEffectCapture.new()
		_capture.buffer_length = 1.0
		AudioServer.add_bus_effect(idx, _capture, 0)
		var amp := AudioEffectAmplify.new()
		amp.volume_db = -80.0
		AudioServer.add_bus_effect(idx, amp, 1)
	else:
		_capture = AudioServer.get_bus_effect(idx, 0) as AudioEffectCapture
	_mic = AudioStreamPlayer.new()
	_mic.stream = AudioStreamMicrophone.new()
	_mic.bus = BUS
	add_child(_mic)


func native_available() -> bool:
	return native_override != null or Engine.has_singleton("VfxRecorder")


func native_probe() -> String:
	if not native_available():
		return "Native recorder plugin is not part of this build."
	var n = native_override if native_override != null else Engine.get_singleton("VfxRecorder")
	return str(n.probe())


func start() -> void:
	note = ""
	native_active = false
	_nr = PackedFloat32Array()
	if use_native and native_available():
		_native = native_override if native_override != null else Engine.get_singleton("VfxRecorder")
		var ch := 2 if native_channels >= 2 else 1
		if _native.start(native_rate, ch, native_source):
			native_active = true
			channels = int(_native.getChannels())
			doc = AudioDoc.new()
			doc.begin_recording(int(_native.getRate()))
		else:
			note = "Native recorder failed: %s. Using Godot's recorder." % str(_native.getError())
			_native = null
	elif use_native:
		note = "Native recorder plugin is not in this build. Using Godot's recorder."
	if not native_active:
		channels = 1
		doc = AudioDoc.new()
		doc.begin_recording(int(AudioServer.get_mix_rate()))
		_capture.clear_buffer()
		_mic.play()
	doc.name = _stamp_name()
	_total = 0
	_warned = false
	_t0 = Time.get_ticks_msec()
	recording = true


## Stops and returns the finished mono document (or null if nothing was captured).
func stop():
	if not recording:
		return null
	_drain()
	recording = false
	if native_active:
		_native.stop()
	else:
		_mic.stop()
	var d = doc
	doc = null
	if d == null or d.length() == 0:
		return null
	if native_active and channels == 2 and _nr.size() == d.left.size():
		d.right = _nr
		d.is_mono = false
		d.build_peaks()
	else:
		d.finish_recording()
	_nr = PackedFloat32Array()
	native_active = false
	return d


func elapsed_sec() -> float:
	return float(doc.length()) / float(doc.rate) if doc != null else 0.0


func _process(_delta: float) -> void:
	if not recording:
		return
	var peak := _drain()
	updated.emit(peak)
	if not _warned and _total == 0 and Time.get_ticks_msec() - _t0 > 1800:
		_warned = true
		no_audio.emit()
	var limit := NATIVE_MAX_SEC if native_active else MAX_SEC
	if doc != null and elapsed_sec() >= limit:
		limit_reached.emit()


func _drain() -> float:
	if native_active:
		return _drain_native()
	var n := _capture.get_frames_available()
	if n <= 0:
		return 0.0
	var fr := _capture.get_buffer(n)
	var mono := PackedFloat32Array()
	mono.resize(fr.size())
	var peak := 0.0
	for i in fr.size():
		var v := (fr[i].x + fr[i].y) * 0.5
		mono[i] = v
		var a := absf(v)
		if a > peak:
			peak = a
	_total += fr.size()
	doc.append_mono(mono)
	return peak


func _drain_native() -> float:
	var raw = _native.drain()
	var arr: PackedFloat32Array = PackedFloat32Array(raw) if not (raw is PackedFloat32Array) else raw
	if arr.is_empty():
		return 0.0
	var ch: int = channels
	var n: int = arr.size() / ch
	var l := PackedFloat32Array()
	l.resize(n)
	var peak := 0.0
	if ch == 2:
		var r := PackedFloat32Array()
		r.resize(n)
		for i in n:
			var a: float = arr[2 * i]
			var b: float = arr[2 * i + 1]
			l[i] = a
			r[i] = b
			var m := maxf(absf(a), absf(b))
			if m > peak:
				peak = m
		_nr.append_array(r)
	else:
		for i in n:
			var a: float = arr[i]
			l[i] = a
			if absf(a) > peak:
				peak = absf(a)
	_total += n
	doc.append_mono(l)
	return peak


func _stamp_name() -> String:
	var t := Time.get_datetime_dict_from_system()
	return "rec_%04d%02d%02d_%02d%02d%02d" % [t.year, t.month, t.day, t.hour, t.minute, t.second]
