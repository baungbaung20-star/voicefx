extends Control
## "Audio Attributes" sheet shown before saving (GoldWave style):
## presets, sample rate (+ custom), collapsible Filter Attributes (channels / type),
## the list of formats, anti-alias option and a file-size estimate.

const P = preload("res://scripts/palette.gd")
const IconButton = preload("res://scripts/ui/icon_button.gd")
const GLYPH = preload("res://scripts/ui/icon_glyph.gd")

signal accepted(fmt: Dictionary)
signal canceled
signal message(text: String)

const RATES := [8000, 11025, 16000, 22050, 32000, 44100, 48000, 88200, 96000, 176400, 192000]
const CUSTOM_ID := 1
const MIN_RATE := 1000
const MAX_RATE := 192000
const PRESET_FILE := "user://export_presets.cfg"

const LBL_W := 160.0      # width of the label column (keeps all rows aligned)
const BTN_H := 56.0       # common height of drop-downs / small buttons
const SIDE_W := 120.0     # width of the "+ -" column
const MAX_W := 900.0      # the sheet never gets wider than this
const HEAVY_SAMPLES := 30000000

var _doc = null
var _formats: Array = []
var _sel: Dictionary = {}
var _rate := 0                  # 0 = same as source
var _ch_filter := "all"
var _type_filter := "all"
var _builtin: Array = []
var _user: Dictionary = {}
var _inset := Vector4.ZERO

var _margin: MarginContainer
var _preset_opt: OptionButton
var _rate_opt: OptionButton
var _custom_nodes: Array = []
var _spin: SpinBox
var _filter_btn: Button
var _filter_body: Control
var _list_box: VBoxContainer
var _group := ButtonGroup.new()
var _aa_check: CheckBox
var _info: Label


func _ready() -> void:
	visible = false
	_build_formats()
	_build_presets()
	_load_user_presets()
	_build_ui()


# ------------------------------------------------------------------ data

func _build_formats() -> void:
	var defs := [
		["PCM unsigned 8 bit", 1, 8, "pcm"],
		["PCM signed 16 bit", 1, 16, "pcm"],
		["PCM signed 24 bit", 1, 24, "pcm"],
		["PCM signed 32 bit", 1, 32, "pcm"],
		["IEEE float signed 32 bit", 3, 32, "float"],
		["IEEE float signed 64 bit", 3, 64, "float"],
		["u-Law", 7, 8, "ulaw"],
		["A-Law", 6, 8, "alaw"],
	]
	for d in defs:
		for ch in [2, 1]:
			_formats.append({"text": "%s, %s" % [d[0], "stereo" if ch == 2 else "mono"], "tag": d[1], "bits": d[2], "ch": ch, "type": d[3]})


func _build_presets() -> void:
	_builtin = [
		{"name": "Same as source", "same": true},
		{"name": "CD quality: 44100 Hz, 16-bit stereo", "rate": 44100, "tag": 1, "bits": 16, "ch": 2},
		{"name": "Video: 48000 Hz, 16-bit stereo", "rate": 48000, "tag": 1, "bits": 16, "ch": 2},
		{"name": "Studio: 48000 Hz, 24-bit stereo", "rate": 48000, "tag": 1, "bits": 24, "ch": 2},
		{"name": "Master: 44100 Hz, float 32 stereo", "rate": 44100, "tag": 3, "bits": 32, "ch": 2},
		{"name": "Voice: 16000 Hz, 16-bit mono", "rate": 16000, "tag": 1, "bits": 16, "ch": 1},
		{"name": "Telephone: 8000 Hz, u-Law mono", "rate": 8000, "tag": 7, "bits": 8, "ch": 1},
	]


func _load_user_presets() -> void:
	_user = {}
	var cfg := ConfigFile.new()
	if cfg.load(PRESET_FILE) == OK:
		for k in cfg.get_section_keys("presets"):
			var v = cfg.get_value("presets", k)
			if v is Dictionary:
				_user[k] = v


func _save_user_presets() -> void:
	var cfg := ConfigFile.new()
	for k in _user:
		cfg.set_value("presets", k, _user[k])
	cfg.save(PRESET_FILE)


func _find_format(tag: int, bits: int, ch: int) -> Dictionary:
	for e in _formats:
		if e["tag"] == tag and e["bits"] == bits and e["ch"] == ch:
			return e
	for e in _formats:
		if e["tag"] == 1 and e["bits"] == 16 and e["ch"] == ch:
			return e
	return _formats[0]


func _source_entry() -> Dictionary:
	var ch := 1 if _doc.is_mono else 2
	return _find_format(_doc.src_tag, _doc.src_bits, ch)


# ------------------------------------------------------------------ UI

func _label(text: String, variation: String = "") -> Label:
	var l := Label.new()
	l.text = text
	if variation != "":
		l.theme_type_variation = variation
	return l


## Label for the first column of a grid: fixed width, vertically centred.
func _row_label(text: String, dim: bool = false) -> Label:
	var l := _label(text, "DimLabel" if dim else "")
	l.custom_minimum_size = Vector2(LBL_W, 0)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	return l


func _icon(kind: String, variation: String, px: int) -> Button:
	var b := IconButton.new()
	b.setup(kind, px)
	b.theme_type_variation = variation
	b.focus_mode = Control.FOCUS_NONE
	return b


func _option() -> OptionButton:
	var o := OptionButton.new()
	o.custom_minimum_size = Vector2(0, BTN_H)
	o.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	o.clip_text = true
	o.fit_to_longest_item = false
	o.focus_mode = Control.FOCUS_NONE
	return o


func _pad(w: float) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(w, 0)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c


func _build_ui() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	resized.connect(_apply_margins)

	var bg := ColorRect.new()
	bg.color = P.BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	_margin = MarginContainer.new()
	_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_margin)

	var card := PanelContainer.new()
	_margin.add_child(card)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 12)
	card.add_child(root)

	# ---- title bar:  X   Audio Attributes   check
	var bar := HBoxContainer.new()
	bar.add_theme_constant_override("separation", 10)
	root.add_child(bar)
	var close := _icon("close", "ToolButton", 68)
	close.pressed.connect(_on_cancel)
	bar.add_child(close)
	var title := _label("Audio Attributes", "TitleLabel")
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.size_flags_vertical = Control.SIZE_FILL
	bar.add_child(title)
	var ok := _icon("check", "AccentButton", 68)
	ok.pressed.connect(_on_accept)
	bar.add_child(ok)

	# ---- scrollable body (everything between the title bar and the footer)
	var body_scroll := ScrollContainer.new()
	body_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_ALWAYS
	root.add_child(body_scroll)
	var body := VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 12)
	body_scroll.add_child(body)
	body_scroll.get_v_scroll_bar().custom_minimum_size.x = 14

	# ---- aligned form: label | drop-down | side column
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 10)
	body.add_child(grid)

	# row 1: presets
	grid.add_child(_row_label("Presets:"))
	_preset_opt = _option()
	_preset_opt.item_selected.connect(_on_preset_selected)
	grid.add_child(_preset_opt)
	var pm := HBoxContainer.new()
	pm.add_theme_constant_override("separation", 8)
	pm.custom_minimum_size = Vector2(SIDE_W, 0)
	grid.add_child(pm)
	var add := _icon("plus", "ToolButton", int(BTN_H))
	add.pressed.connect(_on_preset_add)
	pm.add_child(add)
	var rem := _icon("minus", "ToolButton", int(BTN_H))
	rem.pressed.connect(_on_preset_remove)
	pm.add_child(rem)

	# row 2: sample rate
	grid.add_child(_row_label("Sample rate:"))
	_rate_opt = _option()
	_rate_opt.item_selected.connect(_on_rate_selected)
	grid.add_child(_rate_opt)
	grid.add_child(_pad(SIDE_W))

	# row 3: custom rate (only visible for "Custom...")
	var cl := _row_label("Custom rate:")
	grid.add_child(cl)
	_spin = SpinBox.new()
	_spin.min_value = MIN_RATE
	_spin.max_value = MAX_RATE
	_spin.step = 1
	_spin.value = 44100
	_spin.suffix = "Hz"
	_spin.update_on_text_changed = true
	_spin.custom_minimum_size = Vector2(0, BTN_H)
	_spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_spin.value_changed.connect(_on_spin_changed)
	grid.add_child(_spin)
	var cp := _pad(SIDE_W)
	grid.add_child(cp)
	_custom_nodes = [cl, _spin, cp]
	_set_custom_visible(false)

	# ---- collapsible filter section
	_filter_btn = Button.new()
	_filter_btn.text = "Filter Attributes"
	_filter_btn.theme_type_variation = "FilterHeader"
	_filter_btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
	_filter_btn.toggle_mode = true
	_filter_btn.focus_mode = Control.FOCUS_NONE
	_filter_btn.custom_minimum_size = Vector2(0, BTN_H)
	var chev := GLYPH.new()
	chev.kind = "chevron_down"
	chev.alt_kind = "chevron_up"
	chev.at_right = true
	_filter_btn.add_child(chev)
	_filter_btn.toggled.connect(func(on: bool): _filter_body.visible = on)
	body.add_child(_filter_btn)

	var fg := GridContainer.new()
	fg.columns = 2
	fg.visible = false
	fg.add_theme_constant_override("h_separation", 12)
	fg.add_theme_constant_override("v_separation", 8)
	body.add_child(fg)
	_filter_body = fg
	_add_filter_row(fg, "Channels:", [["All", "all"], ["Mono", "mono"], ["Stereo", "stereo"]], func(v: String): _ch_filter = v)
	_add_filter_row(fg, "Type:", [["All", "all"], ["PCM", "pcm"], ["Float", "float"], ["u-Law", "ulaw"], ["A-Law", "alaw"]], func(v: String): _type_filter = v)

	# ---- format list in its own dark panel (scrolls together with the body)
	var list_panel := PanelContainer.new()
	list_panel.theme_type_variation = "WaveCard"
	body.add_child(list_panel)
	_list_box = VBoxContainer.new()
	_list_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list_box.add_theme_constant_override("separation", 2)
	list_panel.add_child(_list_box)

	# ---- footer
	_aa_check = CheckBox.new()
	_aa_check.text = "Anti-alias filter when lowering the rate"
	_aa_check.button_pressed = true
	_aa_check.focus_mode = Control.FOCUS_NONE
	_aa_check.toggled.connect(func(_on: bool): _update_info())
	root.add_child(_aa_check)
	_info = _label("", "DimLabel")
	_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(_info)

	_apply_margins()


func _add_filter_row(grid: GridContainer, title: String, options: Array, setter: Callable) -> void:
	grid.add_child(_row_label(title, true))
	var row := HBoxContainer.new()
	row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_theme_constant_override("separation", 6)
	grid.add_child(row)
	var group := ButtonGroup.new()
	for o in options:
		var b := Button.new()
		b.text = o[0]
		b.toggle_mode = true
		b.button_group = group
		b.theme_type_variation = "TabButton"
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(0, 52)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.set_pressed_no_signal(o[1] == "all")
		b.toggled.connect(func(on: bool):
			if on:
				setter.call(o[1])
				_refresh_list())
		row.add_child(b)


func set_insets(l: float, t: float, r: float, b: float) -> void:
	_inset = Vector4(l, t, r, b)
	_apply_margins()


func _apply_margins() -> void:
	if _margin == null:
		return
	var side := maxf(0.0, (size.x - MAX_W) * 0.5)
	_margin.add_theme_constant_override("margin_left", 16 + int(maxf(_inset.x, side)))
	_margin.add_theme_constant_override("margin_right", 16 + int(maxf(_inset.z, side)))
	_margin.add_theme_constant_override("margin_top", 16 + int(_inset.y))
	_margin.add_theme_constant_override("margin_bottom", 16 + int(_inset.w))


func _set_custom_visible(on: bool) -> void:
	for n in _custom_nodes:
		n.visible = on


# ------------------------------------------------------------------ open / state

func open(doc) -> void:
	_doc = doc
	_rate_opt.clear()
	_rate_opt.add_item("Source (%d Hz)" % doc.rate, 0)
	for r in RATES:
		_rate_opt.add_item("%d Hz" % r, r)
	_rate_opt.add_item("Custom...", CUSTOM_ID)
	_rate = 0
	_rate_opt.select(0)
	_set_custom_visible(false)
	_rebuild_preset_menu()
	_sel = _source_entry()
	_ch_filter = "all"
	_type_filter = "all"
	_reset_filter_buttons()
	_filter_btn.set_pressed_no_signal(false)
	_filter_body.visible = false
	_aa_check.set_pressed_no_signal(true)
	_refresh_list()
	visible = true


func _reset_filter_buttons() -> void:
	for row in _filter_body.get_children():
		if row is HBoxContainer:
			for c in row.get_children():
				if c is Button:
					c.set_pressed_no_signal(c.text == "All")


func _rebuild_preset_menu() -> void:
	_preset_opt.clear()
	for p in _builtin:
		_preset_opt.add_item(p["name"])
	for k in _user:
		_preset_opt.add_item(k)
	_preset_opt.select(0)


func _matches(e: Dictionary) -> bool:
	if _ch_filter == "mono" and e["ch"] != 1:
		return false
	if _ch_filter == "stereo" and e["ch"] != 2:
		return false
	if _type_filter != "all" and e["type"] != _type_filter:
		return false
	return true


func _same(a: Dictionary, b: Dictionary) -> bool:
	return a["tag"] == b["tag"] and a["bits"] == b["bits"] and a["ch"] == b["ch"]


func _refresh_list() -> void:
	if _list_box == null:
		return
	for c in _list_box.get_children():
		_list_box.remove_child(c)
		c.queue_free()
	for e in _formats:
		if not _matches(e):
			continue
		var cb := CheckBox.new()
		cb.text = e["text"]
		cb.theme_type_variation = "ListRow"
		cb.button_group = _group
		cb.focus_mode = Control.FOCUS_NONE
		cb.custom_minimum_size = Vector2(0, 64)
		cb.set_pressed_no_signal(_same(e, _sel))
		cb.toggled.connect(_on_pick.bind(e))
		_list_box.add_child(cb)
	_update_info()


func _on_pick(on: bool, e: Dictionary) -> void:
	if on:
		_sel = e
		_update_info()


func _on_rate_selected(index: int) -> void:
	var id := _rate_opt.get_item_id(index)
	if id == CUSTOM_ID:
		_set_custom_visible(true)
		_rate = clampi(int(_spin.value), MIN_RATE, MAX_RATE)
	else:
		_set_custom_visible(false)
		_rate = id
	_update_info()


func _on_spin_changed(v: float) -> void:
	if _rate_opt.get_selected_id() == CUSTOM_ID:
		_rate = clampi(int(v), MIN_RATE, MAX_RATE)
		_update_info()


func _out_rate() -> int:
	return _doc.rate if _rate == 0 else _rate


func _fmt_size(bytes: int) -> String:
	if bytes >= 1048576:
		return "%.1f MB" % (float(bytes) / 1048576.0)
	return "%.0f KB" % (float(bytes) / 1024.0)


@warning_ignore("integer_division")
func _fmt_dur(frames: int, rate: int) -> String:
	var sec := float(frames) / float(rate)
	return "%d:%04.1f" % [int(sec) / 60, fmod(sec, 60.0)]


@warning_ignore("integer_division")
func _update_info() -> void:
	if _info == null or _doc == null or _sel.is_empty():
		return
	var rate := _out_rate()
	var frames := int(float(_doc.length()) * float(rate) / float(_doc.rate))
	var ch: int = _sel["ch"]
	var bytes := frames * ch * int(_sel["bits"]) / 8 + 44
	var notes: Array = []
	if rate < _doc.rate:
		if _aa_check.button_pressed:
			notes.append("Lowering the rate: the anti-alias filter makes saving slower.")
		else:
			notes.append("Warning: without the filter, high frequencies can cause aliasing.")
	elif rate > _doc.rate:
		notes.append("Raising the rate does not add detail, the file just gets bigger.")
	if rate != _doc.rate and frames * ch > HEAVY_SAMPLES:
		notes.append("Large conversion: it may be slow or run out of memory on some phones.")
	var text := "%d Hz | %s\nAbout %s for %s" % [rate, _sel["text"], _fmt_size(bytes), _fmt_dur(frames, rate)]
	for n in notes:
		text += "\n" + n
	_info.text = text


# ------------------------------------------------------------------ presets

func _select_rate(rate: int) -> void:
	_rate = rate
	if rate == 0:
		_rate_opt.select(0)
		_set_custom_visible(false)
		return
	for i in _rate_opt.item_count:
		if _rate_opt.get_item_id(i) == rate:
			_rate_opt.select(i)
			_set_custom_visible(false)
			return
	# not in the list: use the custom field
	_spin.set_value_no_signal(rate)
	_rate_opt.select(_rate_opt.get_item_index(CUSTOM_ID))
	_set_custom_visible(true)


func _apply(p: Dictionary) -> void:
	if p.get("same", false):
		_select_rate(0)
		_sel = _source_entry()
	else:
		_select_rate(clampi(int(p.get("rate", 0)), MIN_RATE, MAX_RATE))
		_sel = _find_format(int(p["tag"]), int(p["bits"]), int(p["ch"]))
	_ch_filter = "all"
	_type_filter = "all"
	_reset_filter_buttons()
	_refresh_list()


func _on_preset_selected(index: int) -> void:
	if index < _builtin.size():
		_apply(_builtin[index])
	else:
		var keys := _user.keys()
		var k: String = keys[index - _builtin.size()]
		_apply(_user[k])


func _on_preset_add() -> void:
	var pname := "%d Hz, %s" % [_out_rate(), _sel["text"]]
	_user[pname] = {"rate": _out_rate(), "tag": _sel["tag"], "bits": _sel["bits"], "ch": _sel["ch"]}
	_save_user_presets()
	_rebuild_preset_menu()
	_preset_opt.select(_builtin.size() + _user.keys().find(pname))
	message.emit("Preset saved")


func _on_preset_remove() -> void:
	var index := _preset_opt.selected
	if index < _builtin.size():
		message.emit("Built-in presets cannot be removed")
		return
	var keys := _user.keys()
	_user.erase(keys[index - _builtin.size()])
	_save_user_presets()
	_rebuild_preset_menu()
	message.emit("Preset removed")


# ------------------------------------------------------------------ result

func _on_cancel() -> void:
	visible = false
	canceled.emit()


func _on_accept() -> void:
	if _doc == null or _sel.is_empty():
		return
	var fmt := {
		"tag": _sel["tag"],
		"bits": _sel["bits"],
		"channels": _sel["ch"],
		"rate": _out_rate(),
		"aa": _aa_check.button_pressed,
	}
	visible = false
	accepted.emit(fmt)
