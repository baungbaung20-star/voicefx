extends Button
## A Button that shows a code-drawn vector icon (child Control draws on top).

const GLYPH = preload("res://scripts/ui/icon_glyph.gd")


func setup(kind: String, px: int, tint: Color = Color(0, 0, 0, 0), alt_kind: String = "") -> Button:
	custom_minimum_size = Vector2(px, px)
	var g := GLYPH.new()
	g.kind = kind
	g.alt_kind = alt_kind
	g.tint = tint
	add_child(g)
	return self
