extends Control
## Small app logo: rounded indigo square with white waveform bars.

const P = preload("res://scripts/palette.gd")
const HEIGHTS := [0.35, 0.7, 1.0, 0.55, 0.85]


func _ready() -> void:
	custom_minimum_size = Vector2(52, 52)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	size_flags_vertical = Control.SIZE_SHRINK_CENTER


func _draw() -> void:
	var sb := StyleBoxFlat.new()
	sb.bg_color = P.INDIGO_LIGHT
	sb.set_corner_radius_all(14)
	sb.border_color = P.VIOLET_LIGHT
	sb.set_border_width_all(2)
	sb.anti_aliasing = true
	draw_style_box(sb, Rect2(Vector2.ZERO, size))
	var n := HEIGHTS.size()
	var bw := size.x * 0.09
	var gap := size.x * 0.075
	var total := n * bw + (n - 1) * gap
	var x0 := (size.x - total) * 0.5
	for i in n:
		var h: float = size.y * 0.58 * HEIGHTS[i]
		draw_rect(Rect2(x0 + i * (bw + gap), (size.y - h) * 0.5, bw, h), Color.WHITE)
