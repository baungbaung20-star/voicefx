extends Control
## Input level meter (peak, -60 dB .. 0 dB) with fast attack and smooth release.

const P = preload("res://scripts/palette.gd")
const DB_MIN := -60.0

var _level := 0.0   # linear 0..1 shown
var _hold := 0.0


func _ready() -> void:
	custom_minimum_size = Vector2(0, 30)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func set_level(peak: float) -> void:
	if peak > _level:
		_level = peak
	if peak > _hold:
		_hold = peak


func reset() -> void:
	_level = 0.0
	_hold = 0.0
	queue_redraw()


func peak_db() -> float:
	return 20.0 * log(maxf(_hold, 0.000001)) / log(10.0)


func _frac(lin: float) -> float:
	if lin <= 0.000001:
		return 0.0
	var db := 20.0 * log(lin) / log(10.0)
	return clampf((db - DB_MIN) / -DB_MIN, 0.0, 1.0)


func _process(delta: float) -> void:
	_level = maxf(0.0, _level - delta * 1.2)
	queue_redraw()


func _draw() -> void:
	var r := Rect2(Vector2.ZERO, size)
	var bg := StyleBoxFlat.new()
	bg.bg_color = P.BG_DEEP
	bg.set_corner_radius_all(8)
	bg.border_color = P.BORDER
	bg.set_border_width_all(2)
	draw_style_box(bg, r)
	var inner := r.grow(-4.0)
	var f := _frac(_level)
	if f > 0.0:
		var w := inner.size.x * f
		var col := P.VIOLET
		if f > 0.95:
			col = P.DANGER
		elif f > 0.8:
			col = P.VIOLET_LIGHT
		draw_rect(Rect2(inner.position, Vector2(w, inner.size.y)), col)
	# peak hold marker
	var hf := _frac(_hold)
	if hf > 0.0:
		var x := inner.position.x + inner.size.x * hf
		draw_line(Vector2(x, inner.position.y), Vector2(x, inner.end.y), P.DANGER if hf > 0.95 else Color.WHITE, 2.0)
	# dB ticks
	var font := get_theme_default_font()
	for db in [-60, -40, -20, -6, 0]:
		var tx := inner.position.x + inner.size.x * (float(db) - DB_MIN) / -DB_MIN
		draw_line(Vector2(tx, inner.end.y - 6), Vector2(tx, inner.end.y), P.TEXT_DIM, 1.0)
