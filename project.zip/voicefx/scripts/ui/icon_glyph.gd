extends Control
## Draws a vector icon on top of its parent button (no image files needed).

const P = preload("res://scripts/palette.gd")

var kind: String = "play"
## When the parent is a toggle button and is pressed, this icon is drawn instead.
var alt_kind: String = ""
var tint: Color = Color(0, 0, 0, 0)
## Draw the glyph near the right edge (for chevrons inside wide buttons).
var at_right := false


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var p := get_parent()
	if p is BaseButton:
		p.draw.connect(queue_redraw)


func _draw() -> void:
	var btn := get_parent() as BaseButton
	var col: Color = P.TEXT
	var k := kind
	if btn != null:
		if btn.disabled:
			col = P.TEXT_DIM.darkened(0.45)
		else:
			if tint.a > 0.0:
				col = tint
			if btn.toggle_mode and btn.button_pressed:
				col = Color.WHITE
				if alt_kind != "":
					k = alt_kind
	var c := size * 0.5
	if at_right:
		c = Vector2(size.x - 34.0, size.y * 0.5)
	var s := minf(size.x, size.y) * 0.27
	match k:
		"play":
			draw_colored_polygon(PackedVector2Array([
				Vector2(c.x - s * 0.7, c.y - s), Vector2(c.x + s * 1.0, c.y), Vector2(c.x - s * 0.7, c.y + s)]), col)
		"pause":
			draw_rect(Rect2(c.x - s * 0.9, c.y - s, s * 0.65, s * 2.0), col)
			draw_rect(Rect2(c.x + s * 0.25, c.y - s, s * 0.65, s * 2.0), col)
		"stop":
			draw_rect(Rect2(c.x - s * 0.9, c.y - s * 0.9, s * 1.8, s * 1.8), col)
		"record":
			draw_circle(c, s * 1.0, col)
		"to_start":
			draw_rect(Rect2(c.x - s, c.y - s, s * 0.3, s * 2.0), col)
			draw_colored_polygon(PackedVector2Array([
				Vector2(c.x + s, c.y - s), Vector2(c.x - s * 0.5, c.y), Vector2(c.x + s, c.y + s)]), col)
		"to_end":
			draw_rect(Rect2(c.x + s * 0.7, c.y - s, s * 0.3, s * 2.0), col)
			draw_colored_polygon(PackedVector2Array([
				Vector2(c.x - s, c.y - s), Vector2(c.x + s * 0.5, c.y), Vector2(c.x - s, c.y + s)]), col)
		"loop":
			var a0 := -PI * 0.15
			var a1 := PI * 1.55
			draw_arc(c, s, a0, a1, 28, col, 3.5, true)
			var e := c + Vector2(cos(a1), sin(a1)) * s
			var tan_v := Vector2(-sin(a1), cos(a1))
			var nor_v := Vector2(cos(a1), sin(a1))
			draw_colored_polygon(PackedVector2Array([
				e + tan_v * s * 0.6, e + nor_v * s * 0.5, e - nor_v * s * 0.5]), col)
		"zoom_in", "zoom_out":
			var lc := c - Vector2(s * 0.15, s * 0.15)
			draw_arc(lc, s * 0.85, 0.0, TAU, 28, col, 3.0, true)
			draw_line(lc + Vector2(s * 0.6, s * 0.6), lc + Vector2(s * 1.25, s * 1.25), col, 4.0, true)
			draw_line(lc + Vector2(-s * 0.4, 0), lc + Vector2(s * 0.4, 0), col, 3.0, true)
			if k == "zoom_in":
				draw_line(lc + Vector2(0, -s * 0.4), lc + Vector2(0, s * 0.4), col, 3.0, true)
		"fit":
			draw_line(Vector2(c.x - s, c.y - s), Vector2(c.x - s, c.y + s), col, 3.0, true)
			draw_line(Vector2(c.x + s, c.y - s), Vector2(c.x + s, c.y + s), col, 3.0, true)
			draw_line(Vector2(c.x - s * 0.6, c.y), Vector2(c.x + s * 0.6, c.y), col, 3.0, true)
			draw_colored_polygon(PackedVector2Array([
				Vector2(c.x - s * 0.6, c.y - s * 0.35), Vector2(c.x - s * 0.05, c.y), Vector2(c.x - s * 0.6, c.y + s * 0.35)]), col)
			draw_colored_polygon(PackedVector2Array([
				Vector2(c.x + s * 0.6, c.y - s * 0.35), Vector2(c.x + s * 0.05, c.y), Vector2(c.x + s * 0.6, c.y + s * 0.35)]), col)
		"undo", "redo":
			var dir := -1.0 if k == "undo" else 1.0
			var ac := c + Vector2(0, s * 0.25)
			var r := s * 0.9
			if k == "undo":
				draw_arc(ac, r, PI, TAU + 0.7, 24, col, 3.5, true)
			else:
				draw_arc(ac, r, PI - 0.7, TAU, 24, col, 3.5, true)
			var hx := ac.x + dir * r
			draw_colored_polygon(PackedVector2Array([
				Vector2(hx - s * 0.45, ac.y), Vector2(hx + s * 0.45, ac.y), Vector2(hx, ac.y + s * 0.65)]), col)
		"close":
			draw_line(c + Vector2(-s, -s), c + Vector2(s, s), col, 4.0, true)
			draw_line(c + Vector2(-s, s), c + Vector2(s, -s), col, 4.0, true)
		"check":
			draw_polyline(PackedVector2Array([c + Vector2(-s, 0.1 * s), c + Vector2(-s * 0.3, s * 0.8), c + Vector2(s, -s * 0.7)]), col, 4.5, true)
		"plus":
			draw_line(c + Vector2(-s, 0), c + Vector2(s, 0), col, 4.0, true)
			draw_line(c + Vector2(0, -s), c + Vector2(0, s), col, 4.0, true)
		"minus":
			draw_line(c + Vector2(-s, 0), c + Vector2(s, 0), col, 4.0, true)
		"chevron_down":
			draw_polyline(PackedVector2Array([c + Vector2(-s, -s * 0.4), c + Vector2(0, s * 0.5), c + Vector2(s, -s * 0.4)]), col, 4.0, true)
		"chevron_up":
			draw_polyline(PackedVector2Array([c + Vector2(-s, s * 0.4), c + Vector2(0, -s * 0.5), c + Vector2(s, s * 0.4)]), col, 4.0, true)
