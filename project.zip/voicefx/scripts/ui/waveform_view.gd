extends Control
## Stereo waveform view (L on top, R below) with time ruler, playhead,
## zoom (pinch / buttons / mouse wheel), scroll (drag / overview strip) and tap-to-seek.
## The waveform geometry is cached and rebuilt only when the view changes,
## so playback only redraws a cheap playhead.

const P = preload("res://scripts/palette.gd")

signal seek_requested(frame: int)
signal view_changed

const RULER_H := 34.0
const LABEL_W := 44.0
const LANE_GAP := 6.0
const STRIP_H := 24.0
const TAP_SLOP := 14.0
const MIN_SPP := 1.0 / 48.0
const LIVE_WINDOW_SEC := 8.0
const STEPS := [0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 5.0, 10.0, 15.0, 30.0, 60.0, 120.0, 300.0, 600.0, 1800.0]

var doc = null
## Live (recording) mode: fixed time window that follows the end of a growing document.
var live := false
var view_start := 0.0   # first visible frame
var spp := 256.0        # frames per pixel
var playhead := 0

var _dirty := true
var _fit_pending := false
var _lines: Array = [PackedVector2Array(), PackedVector2Array()]
var _poly: Array = [PackedVector2Array(), PackedVector2Array()]
var _dots := false

var _touches := {}
var _pinching := false
var _pinch_d0 := 1.0
var _pinch_spp0 := 1.0
var _pinch_anchor := 0.0
var _mouse_down := false
var _drag := false
var _strip_drag := false
var _down_pos := Vector2.ZERO
var _down_view := 0.0


func _ready() -> void:
	clip_contents = true
	resized.connect(_on_resized)


# ------------------------------------------------------------------ public API

func set_doc(d) -> void:
	doc = d
	playhead = 0
	view_start = 0.0
	_fit_pending = true
	_dirty = true
	queue_redraw()


func set_playhead(f: int) -> void:
	playhead = f
	queue_redraw()


func set_live(on: bool) -> void:
	live = on
	_touches.clear()
	_pinching = false
	_mouse_down = false
	_drag = false


## Call after the live document grew: keeps the last LIVE_WINDOW_SEC visible.
func live_update() -> void:
	if doc == null:
		return
	_fit_pending = false
	spp = maxf(LIVE_WINDOW_SEC * float(doc.rate) / _plot_w(), 1.0)
	view_start = maxf(0.0, float(doc.length()) - visible_frames())
	_dirty = true
	queue_redraw()


func zoom_fit() -> void:
	if live or doc == null or doc.length() == 0:
		return
	spp = maxf(float(doc.length()) / _plot_w(), MIN_SPP)
	view_start = 0.0
	_view_changed()


func zoom_by(factor: float, anchor_x: float = -1.0) -> void:
	if live or doc == null:
		return
	var ax := anchor_x if anchor_x >= 0.0 else LABEL_W + _plot_w() * 0.5
	var af := x_to_frame(ax)
	spp = _clamp_spp(spp / factor)
	view_start = af - (ax - LABEL_W) * spp
	_clamp_view()
	_view_changed()


## Zoom around the playhead if it is visible, otherwise around the view centre.
func zoom_around_playhead(factor: float) -> void:
	var x := frame_to_x(float(playhead))
	if x >= LABEL_W and x <= size.x:
		zoom_by(factor, x)
	else:
		zoom_by(factor)


## Page-scroll so a moving playhead stays visible (used during playback).
func follow(frame: int) -> void:
	if live or doc == null or _mouse_down or _pinching:
		return
	var vis := visible_frames()
	if float(frame) > view_start + vis * 0.97 or float(frame) < view_start:
		view_start = float(frame) - vis * 0.05
		_clamp_view()
		_view_changed()


func frame_to_x(f: float) -> float:
	return LABEL_W + (f - view_start) / spp


func x_to_frame(x: float) -> float:
	return view_start + (x - LABEL_W) * spp


func visible_frames() -> float:
	return _plot_w() * spp


# ------------------------------------------------------------------ geometry

func _plot_w() -> float:
	return maxf(1.0, size.x - LABEL_W)


func _lane_rect(ch: int) -> Rect2:
	var lane_h := maxf(10.0, (size.y - RULER_H - STRIP_H - LANE_GAP * 3.0) * 0.5)
	var y0 := RULER_H + LANE_GAP + ch * (lane_h + LANE_GAP)
	return Rect2(0.0, y0, size.x, lane_h)


func _clamp_spp(v: float) -> float:
	if live:
		return maxf(v, MIN_SPP)
	var max_spp := MIN_SPP
	if doc != null and doc.length() > 0:
		max_spp = maxf(float(doc.length()) / _plot_w(), MIN_SPP)
	return clampf(v, MIN_SPP, max_spp)


func _clamp_view() -> void:
	if doc == null:
		view_start = 0.0
		return
	spp = _clamp_spp(spp)
	var n := float(doc.length())
	view_start = clampf(view_start, 0.0, maxf(0.0, n - visible_frames()))


func _view_changed() -> void:
	_dirty = true
	queue_redraw()
	view_changed.emit()


func _on_resized() -> void:
	if doc != null:
		if _fit_pending:
			return
		_clamp_view()
	_dirty = true
	queue_redraw()


# ------------------------------------------------------------------ cache

func _rebuild_cache() -> void:
	_dirty = false
	for ch in 2:
		_lines[ch] = PackedVector2Array()
		_poly[ch] = PackedVector2Array()
	_dots = false
	if doc == null or doc.length() == 0:
		return
	var n: int = doc.length()
	var pw := int(_plot_w())
	if spp >= 1.0:
		var cols := mini(pw, int(ceil((float(n) - view_start) / spp)))
		if cols <= 0:
			return
		for ch in 2:
			var lr := _lane_rect(ch)
			var mid := lr.position.y + lr.size.y * 0.5
			var half := lr.size.y * 0.5 * 0.92
			var pk: PackedFloat32Array = doc.column_peaks(ch, view_start, spp, cols)
			var pts := PackedVector2Array()
			pts.resize(cols * 2)
			for c in cols:
				var x := LABEL_W + float(c) + 0.5
				var y_hi := mid - pk[c * 2 + 1] * half
				var y_lo := mid - pk[c * 2] * half
				if y_lo - y_hi < 1.0:
					y_lo = y_hi + 1.0
				pts[c * 2] = Vector2(x, y_hi)
				pts[c * 2 + 1] = Vector2(x, y_lo)
			_lines[ch] = pts
	else:
		var f0 := maxi(0, int(floor(view_start)) - 1)
		var f1 := mini(n - 1, int(ceil(view_start + float(pw) * spp)) + 1)
		if f1 < f0:
			return
		_dots = (1.0 / spp) >= 8.0
		for ch in 2:
			var lr := _lane_rect(ch)
			var mid := lr.position.y + lr.size.y * 0.5
			var half := lr.size.y * 0.5 * 0.92
			var a: PackedFloat32Array = doc.channel(ch)
			var pts := PackedVector2Array()
			pts.resize(f1 - f0 + 1)
			for i in range(f0, f1 + 1):
				pts[i - f0] = Vector2(frame_to_x(float(i)), mid - a[i] * half)
			_poly[ch] = pts


# ------------------------------------------------------------------ drawing

func _nice_step(pps: float) -> float:
	for s in STEPS:
		if s * pps >= 96.0:
			return s
	return STEPS[STEPS.size() - 1]


func _fmt_ruler(t: float, step: float) -> String:
	t = snappedf(t, 0.0001)
	var m := floori(t / 60.0)
	var s := t - float(m) * 60.0
	if step >= 1.0:
		return "%d:%02d" % [m, int(s + 0.001)]
	elif step >= 0.1:
		return "%d:%04.1f" % [m, s]
	elif step >= 0.01:
		return "%d:%05.2f" % [m, s]
	return "%d:%06.3f" % [m, s]


func _draw() -> void:
	var w := size.x
	var h := size.y
	if w < 10.0 or h < 10.0:
		return
	if _fit_pending and doc != null and w > 100.0:
		_fit_pending = false
		spp = maxf(float(doc.length()) / _plot_w(), MIN_SPP)
		view_start = 0.0
		_dirty = true
	if _dirty:
		_rebuild_cache()

	var font := get_theme_default_font()
	var names := ["L", "R"]
	var cols := [P.WAVE_L, P.WAVE_R]

	# ruler background
	draw_rect(Rect2(0, 0, w, RULER_H), P.SURFACE)

	# lanes
	var lanes_bottom := h - STRIP_H
	for ch in 2:
		var lr := _lane_rect(ch)
		var y0 := lr.position.y
		var lh := lr.size.y
		draw_rect(Rect2(0, y0, w, lh), P.BG_DEEP.lightened(0.03))
		draw_rect(Rect2(0, y0, LABEL_W, lh), P.SURFACE)
		draw_string(font, Vector2(0, y0 + lh * 0.5 + 9), names[ch], HORIZONTAL_ALIGNMENT_CENTER, LABEL_W, 26, cols[ch])
		var mid := y0 + lh * 0.5
		draw_line(Vector2(LABEL_W, mid - lh * 0.25), Vector2(w, mid - lh * 0.25), Color(P.BORDER, 0.55), 1.0)
		draw_line(Vector2(LABEL_W, mid + lh * 0.25), Vector2(w, mid + lh * 0.25), Color(P.BORDER, 0.55), 1.0)
		draw_line(Vector2(LABEL_W, mid), Vector2(w, mid), Color(cols[ch], 0.45), 1.0)

	# ruler ticks + vertical grid
	if doc != null and doc.length() > 0:
		var rate: float = float(doc.rate)
		var pps := rate / spp
		var step := _nice_step(pps)
		var sub := step / 5.0
		var t0 := view_start / rate
		var t1 := (view_start + visible_frames()) / rate
		var m0 := int(floor(t0 / sub))
		var m1 := int(ceil(t1 / sub))
		if m1 - m0 < 600:
			for m in range(m0, m1 + 1):
				var t := float(m) * sub
				var x := frame_to_x(t * rate)
				if x < LABEL_W - 1.0 or x > w:
					continue
				if m % 5 == 0:
					draw_line(Vector2(x, RULER_H - 14.0), Vector2(x, RULER_H), P.TEXT_DIM, 1.5)
					draw_line(Vector2(x, RULER_H), Vector2(x, lanes_bottom), Color(P.BORDER, 0.45), 1.0)
					draw_string(font, Vector2(x + 5.0, 20.0), _fmt_ruler(t, step), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, P.TEXT_DIM)
				else:
					draw_line(Vector2(x, RULER_H - 7.0), Vector2(x, RULER_H), Color(P.TEXT_DIM, 0.7), 1.0)
		# end-of-file marker
		var xe := frame_to_x(float(doc.length()))
		if xe >= LABEL_W and xe <= w:
			draw_rect(Rect2(xe, RULER_H, w - xe, lanes_bottom - RULER_H), Color(0, 0, 0, 0.35))
			draw_line(Vector2(xe, RULER_H), Vector2(xe, lanes_bottom), P.VIOLET_LIGHT, 1.5)

	# waveform
	for ch in 2:
		var col: Color = cols[ch]
		if spp >= 1.0:
			var pts: PackedVector2Array = _lines[ch]
			if pts.size() >= 2:
				draw_multiline(pts, col, 1.0)
		else:
			var poly: PackedVector2Array = _poly[ch]
			if poly.size() >= 2:
				draw_polyline(poly, col, 2.0, true)
				if _dots:
					for p in poly:
						draw_circle(p, 3.5, Color.WHITE)

	# empty-state hint
	if doc == null:
		draw_string(font, Vector2(LABEL_W, h * 0.5 + 8), "Open a WAV file or press Record", HORIZONTAL_ALIGNMENT_CENTER, w - LABEL_W, 24, P.TEXT_DIM)

	# playhead
	if doc != null:
		var px := frame_to_x(float(playhead))
		if px >= LABEL_W - 1.0 and px <= w:
			draw_line(Vector2(px, 0), Vector2(px, lanes_bottom), Color.WHITE, 2.0)
			draw_colored_polygon(PackedVector2Array([Vector2(px - 8, 0), Vector2(px + 8, 0), Vector2(px, 12)]), P.VIOLET_LIGHT)

	# overview strip
	var sy := h - STRIP_H
	draw_rect(Rect2(0, sy, w, STRIP_H), P.SURFACE)
	if doc != null and doc.length() > 0:
		var n := float(doc.length())
		var pw := _plot_w()
		var tx := LABEL_W + view_start / n * pw
		var tw := maxf(14.0, visible_frames() / n * pw)
		draw_rect(Rect2(tx, sy + 3, tw, STRIP_H - 6), Color(P.VIOLET, 0.65))
		var hx := LABEL_W + float(playhead) / n * pw
		draw_line(Vector2(hx, sy + 2), Vector2(hx, h - 2), Color.WHITE, 2.0)
	else:
		draw_rect(Rect2(LABEL_W, sy + 3, w - LABEL_W, STRIP_H - 6), Color(P.BORDER, 0.5))


# ------------------------------------------------------------------ input

func _strip_to(x: float) -> void:
	if doc == null or doc.length() == 0:
		return
	var n := float(doc.length())
	var centre := (x - LABEL_W) / _plot_w() * n
	view_start = centre - visible_frames() * 0.5
	_clamp_view()
	_view_changed()


func _begin_pinch() -> void:
	var ks := _touches.keys()
	var a: Vector2 = _touches[ks[0]]
	var b: Vector2 = _touches[ks[1]]
	_pinching = true
	_mouse_down = false
	_drag = false
	_strip_drag = false
	_pinch_d0 = maxf(10.0, a.distance_to(b))
	_pinch_spp0 = spp
	_pinch_anchor = x_to_frame((a.x + b.x) * 0.5)


func _update_pinch() -> void:
	var ks := _touches.keys()
	var a: Vector2 = _touches[ks[0]]
	var b: Vector2 = _touches[ks[1]]
	var d := maxf(10.0, a.distance_to(b))
	var cx := (a.x + b.x) * 0.5
	spp = _clamp_spp(_pinch_spp0 * _pinch_d0 / d)
	view_start = _pinch_anchor - (cx - LABEL_W) * spp
	_clamp_view()
	_view_changed()


func _gui_input(event: InputEvent) -> void:
	if doc == null or live:
		return
	if event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			_touches[st.index] = st.position
			if _touches.size() == 2:
				_begin_pinch()
		else:
			_touches.erase(st.index)
			if _touches.size() < 2:
				_pinching = false
	elif event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		if _touches.has(sd.index):
			_touches[sd.index] = sd.position
		if _pinching and _touches.size() >= 2:
			_update_pinch()
	elif event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				if _pinching or _touches.size() >= 2:
					return
				_mouse_down = true
				_drag = false
				_down_pos = mb.position
				_down_view = view_start
				_strip_drag = mb.position.y >= size.y - STRIP_H
				if _strip_drag:
					_strip_to(mb.position.x)
			else:
				if _mouse_down and not _drag and not _strip_drag:
					_tap(mb.position)
				_mouse_down = false
				_drag = false
				_strip_drag = false
		elif mb.pressed and (mb.button_index == MOUSE_BUTTON_WHEEL_UP or mb.button_index == MOUSE_BUTTON_WHEEL_DOWN):
			var up := mb.button_index == MOUSE_BUTTON_WHEEL_UP
			if mb.shift_pressed:
				view_start += (-1.0 if up else 1.0) * visible_frames() * 0.2
				_clamp_view()
				_view_changed()
			else:
				zoom_by(1.25 if up else 0.8, mb.position.x)
	elif event is InputEventMouseMotion:
		if not _mouse_down or _pinching or _touches.size() >= 2:
			return
		var mm := event as InputEventMouseMotion
		if _strip_drag:
			_strip_to(mm.position.x)
			return
		if not _drag and absf(mm.position.x - _down_pos.x) > TAP_SLOP:
			_drag = true
		if _drag:
			view_start = _down_view - (mm.position.x - _down_pos.x) * spp
			_clamp_view()
			_view_changed()


func _tap(pos: Vector2) -> void:
	if doc == null or pos.x < LABEL_W or pos.y >= size.y - STRIP_H:
		return
	var f := clampi(int(x_to_frame(pos.x)), 0, doc.length())
	seek_requested.emit(f)
