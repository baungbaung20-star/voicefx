extends Control
## Voice FX Studio - Step 1: theme + main layout.
## The whole UI is built in code; main.tscn only holds this root Control.

const P = preload("res://scripts/palette.gd")
const ThemeBuilder = preload("res://scripts/theme_builder.gd")
const IconButton = preload("res://scripts/ui/icon_button.gd")
const WaveformView = preload("res://scripts/ui/waveform_view.gd")
const LogoMark = preload("res://scripts/ui/logo_mark.gd")
const WavIO = preload("res://scripts/wav_io.gd")
const PlaybackEngine = preload("res://scripts/player.gd")
const Recorder = preload("res://scripts/recorder.gd")
const LevelMeter = preload("res://scripts/ui/level_meter.gd")
const ExportDialog = preload("res://scripts/ui/export_dialog.gd")
const AudioDocScript = preload("res://scripts/audio_doc.gd")

## "New (empty)" uses the engine mix rate (Project Settings > Audio > Mix Rate) - the same rate
## Record uses - so an empty file never changes rate when you start recording.
const FALLBACK_RATE := 48000

const BASE_PORTRAIT := Vector2i(720, 1280)
const BASE_LANDSCAPE := Vector2i(1280, 720)
const PAD := 14

const EDIT_ACTIONS := ["Cut", "Copy", "Paste", "Delete", "Silence", "Select All", "Fade In", "Fade Out", "Normalize", "Reverse"]
const FX_ACTIONS := ["Amplify", "Delay", "Distortion", "EQ", "Compressor", "Limiter"]
const EDIT_STEP := 4
const FX_STEP := 5

var _margin: MarginContainer
var _body: BoxContainer
var _left: VBoxContainer
var _tabs_panel: PanelContainer
var _wave: Control
var _time_label: Label
var _total_label: Label
var _file_label: Label
var _fmt_label: Label
var _tab_buttons: Array[Button] = []
var _tab_pages: Array[Control] = []
var _tab_grids: Array[GridContainer] = []
var _toast_panel: PanelContainer
var _toast_label: Label
var _toast_tween: Tween
var _landscape := false
var _layout_ready := false

# audio / files
var _doc = null
var _playhead := 0
var _play_origin := 0
var _engine: Node
var _btn_play: Button
var _btn_loop: Button
var _menu: PopupMenu
var _file_dialog: FileDialog
var _file_mode := "open"
var _overlay: Control
var _overlay_label: Label
var _bar: ProgressBar
var _thread: Thread
var _job_kind := ""
var _job_result: Dictionary = {}
var _progress := 0.0

# recording
var _recorder: Node
var _meter: Control
var _rec_status: Label
var _btn_rec: Button
var _choice: Control
var _confirm: ConfirmationDialog
var _rec_mode := "new"
var _pending_rec := false
var _rec_ui_t := 0.0
var _export: Control
var _pending_fmt: Dictionary = {}
var _rec_at := 0   # playhead position when recording started (insert point)


func _ready() -> void:
	theme = ThemeBuilder.build()
	_engine = PlaybackEngine.new()
	add_child(_engine)
	_engine.finished.connect(_on_play_finished)
	_recorder = Recorder.new()
	add_child(_recorder)
	_recorder.updated.connect(_on_rec_updated)
	_recorder.limit_reached.connect(_on_rec_limit)
	_recorder.no_audio.connect(_on_rec_no_audio)
	get_tree().on_request_permissions_result.connect(_on_permission_result)
	_build_ui()
	get_window().size_changed.connect(_on_window_resized)
	get_window().files_dropped.connect(_on_files_dropped)
	_on_window_resized()
	_tab_buttons[0].set_pressed_no_signal(true)
	_show_tab(0)
	if "--demo" in OS.get_cmdline_user_args():
		_set_doc(WavIO.make_demo())


func _exit_tree() -> void:
	if _thread != null and _thread.is_started():
		_thread.wait_to_finish()


# ------------------------------------------------------------------ UI build

func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = P.BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	_margin = MarginContainer.new()
	_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_margin)

	var root_v := VBoxContainer.new()
	root_v.add_theme_constant_override("separation", 10)
	_margin.add_child(root_v)

	root_v.add_child(_build_header())
	root_v.add_child(_build_gradient_strip())

	_body = BoxContainer.new()
	_body.vertical = true
	_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_body.add_theme_constant_override("separation", 10)
	root_v.add_child(_body)

	_left = VBoxContainer.new()
	_left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_left.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_left.add_theme_constant_override("separation", 10)
	_body.add_child(_left)

	_left.add_child(_build_info_panel())
	_left.add_child(_build_wave_panel())
	_left.add_child(_build_tools_row())
	_left.add_child(_build_transport())

	_tabs_panel = _build_tabs_panel()
	_body.add_child(_tabs_panel)

	_build_export()
	_build_toast()
	_build_menu_and_dialog()
	_build_choice()
	_build_overlay()


func _spacer() -> Control:
	var c := Control.new()
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c


func _text_button(text: String, variation: String = "") -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	if variation != "":
		b.theme_type_variation = variation
	return b


func _icon_button(kind: String, variation: String, px: int, tint: Color = Color(0, 0, 0, 0), alt_kind: String = "") -> Button:
	var b := IconButton.new()
	b.setup(kind, px, tint, alt_kind)
	b.theme_type_variation = variation
	b.focus_mode = Control.FOCUS_NONE
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	return b


func _label(text: String, variation: String = "") -> Label:
	var l := Label.new()
	l.text = text
	if variation != "":
		l.theme_type_variation = variation
	return l


func _build_header() -> Control:
	var panel := PanelContainer.new()
	panel.theme_type_variation = "Header"
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	panel.add_child(row)

	row.add_child(LogoMark.new())
	var title := _label("Voice FX Studio", "TitleLabel")
	title.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(title)
	row.add_child(_spacer())

	var open_btn := _text_button("Open")
	open_btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	open_btn.pressed.connect(_on_open_pressed.bind(open_btn))
	row.add_child(open_btn)

	var save_btn := _text_button("Save", "AccentButton")
	save_btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	save_btn.pressed.connect(_on_save_pressed)
	row.add_child(save_btn)
	return panel


func _build_gradient_strip() -> Control:
	var g := Gradient.new()
	g.set_color(0, P.INDIGO)
	g.set_color(1, P.VIOLET_LIGHT)
	g.add_point(0.55, P.VIOLET)
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.width = 512
	gt.height = 4
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(1, 0)
	var tr := TextureRect.new()
	tr.texture = gt
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.custom_minimum_size = Vector2(0, 4)
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return tr


func _build_info_panel() -> Control:
	var panel := PanelContainer.new()
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	panel.add_child(row)

	var left := VBoxContainer.new()
	left.add_theme_constant_override("separation", -4)
	row.add_child(left)
	_time_label = _label("00:00.000", "TimeLabel")
	left.add_child(_time_label)
	_total_label = _label("/ 00:00.000", "DimLabel")
	left.add_child(_total_label)

	row.add_child(_spacer())

	var right := VBoxContainer.new()
	right.alignment = BoxContainer.ALIGNMENT_CENTER
	right.add_theme_constant_override("separation", 2)
	row.add_child(right)
	_file_label = _label("No file loaded")
	_file_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_file_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	_file_label.custom_minimum_size = Vector2(190, 0)
	right.add_child(_file_label)
	_fmt_label = _label("- Hz | - ch | 16-bit", "DimLabel")
	_fmt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	right.add_child(_fmt_label)
	return panel


func _build_wave_panel() -> Control:
	var panel := PanelContainer.new()
	panel.theme_type_variation = "WaveCard"
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_wave = WaveformView.new()
	_wave.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_wave.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_wave.custom_minimum_size = Vector2(0, 240)
	_wave.seek_requested.connect(_on_seek)
	panel.add_child(_wave)
	return panel


func _build_tools_row() -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)

	var zin := _icon_button("zoom_in", "ToolButton", 64)
	zin.pressed.connect(func(): _wave.zoom_around_playhead(2.0))
	row.add_child(zin)
	var zout := _icon_button("zoom_out", "ToolButton", 64)
	zout.pressed.connect(func(): _wave.zoom_around_playhead(0.5))
	row.add_child(zout)
	var fit := _icon_button("fit", "ToolButton", 64)
	fit.pressed.connect(func(): _wave.zoom_fit())
	row.add_child(fit)

	row.add_child(_spacer())

	var undo := _icon_button("undo", "ToolButton", 64)
	undo.pressed.connect(_stub.bind("Undo", EDIT_STEP))
	row.add_child(undo)
	var redo := _icon_button("redo", "ToolButton", 64)
	redo.pressed.connect(_stub.bind("Redo", EDIT_STEP))
	row.add_child(redo)
	return row


func _build_transport() -> Control:
	var panel := PanelContainer.new()
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 14)
	panel.add_child(row)

	var to_start := _icon_button("to_start", "RoundButton", 68)
	to_start.pressed.connect(_on_to_start)
	row.add_child(to_start)

	var stop := _icon_button("stop", "RoundButton", 68)
	stop.pressed.connect(_on_stop)
	row.add_child(stop)

	_btn_play = _icon_button("play", "AccentRound", 100, Color.WHITE, "pause")
	_btn_play.toggle_mode = true
	_btn_play.pressed.connect(_on_play_pressed)
	row.add_child(_btn_play)

	_btn_rec = _icon_button("record", "DangerRound", 84, Color(0, 0, 0, 0), "stop")
	_btn_rec.toggle_mode = true
	_btn_rec.pressed.connect(_on_record_pressed)
	row.add_child(_btn_rec)

	_btn_loop = _icon_button("loop", "RoundButton", 68)
	_btn_loop.toggle_mode = true
	_btn_loop.pressed.connect(_on_loop_pressed)
	row.add_child(_btn_loop)

	var to_end := _icon_button("to_end", "RoundButton", 68)
	to_end.pressed.connect(_on_to_end)
	row.add_child(to_end)
	return panel


func _build_tabs_panel() -> PanelContainer:
	var panel := PanelContainer.new()
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	panel.add_child(v)

	var tab_row := HBoxContainer.new()
	tab_row.add_theme_constant_override("separation", 8)
	v.add_child(tab_row)
	var group := ButtonGroup.new()
	var names := ["Edit", "Effects", "Record"]
	for i in names.size():
		var b := _text_button(names[i], "TabButton")
		b.toggle_mode = true
		b.button_group = group
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.toggled.connect(_on_tab_toggled.bind(i))
		tab_row.add_child(b)
		_tab_buttons.append(b)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(scroll)

	var stack := VBoxContainer.new()
	stack.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(stack)

	_tab_pages.append(_build_action_page(EDIT_ACTIONS, EDIT_STEP, "Select a region on the waveform, then edit."))
	_tab_pages.append(_build_action_page(FX_ACTIONS, FX_STEP, "Effects are applied offline to the selection (or whole file)."))
	_tab_pages.append(_build_record_page())
	for p in _tab_pages:
		stack.add_child(p)
	return panel


func _build_action_page(actions: Array, step: int, hint: String) -> Control:
	var page := VBoxContainer.new()
	page.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	page.add_theme_constant_override("separation", 10)

	var grid := GridContainer.new()
	grid.columns = 3
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	page.add_child(grid)
	_tab_grids.append(grid)

	for a in actions:
		var b := _text_button(a)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.custom_minimum_size = Vector2(0, 72)
		b.pressed.connect(_stub.bind(a, step))
		grid.add_child(b)

	var h := _label(hint, "DimLabel")
	h.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	h.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	page.add_child(h)
	return page


func _build_record_page() -> Control:
	var page := VBoxContainer.new()
	page.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	page.add_theme_constant_override("separation", 12)
	page.add_child(_label("Input level"))
	_meter = LevelMeter.new()
	page.add_child(_meter)
	_build_native_options(page)
	_rec_status = _label(_idle_rec_text(), "DimLabel")
	_rec_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_rec_status.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	page.add_child(_rec_status)
	var h := _label("Plain recording: no effects, nothing is played back while recording (no feedback). Use headphones later for monitoring.", "DimLabel")
	h.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	h.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	page.add_child(h)
	return page


func _build_toast() -> void:
	var overlay := VBoxContainer.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.alignment = BoxContainer.ALIGNMENT_END
	add_child(overlay)

	_toast_panel = PanelContainer.new()
	_toast_panel.theme_type_variation = "Toast"
	_toast_panel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast_panel.modulate.a = 0.0
	overlay.add_child(_toast_panel)

	_toast_label = _label("", "ToastLabel")
	_toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast_panel.add_child(_toast_label)

	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 170)
	gap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(gap)


# ------------------------------------------------------------------ behaviour

func _on_tab_toggled(on: bool, index: int) -> void:
	if on:
		_show_tab(index)


func _show_tab(index: int) -> void:
	for i in _tab_pages.size():
		_tab_pages[i].visible = (i == index)


func _stub(what: String, step: int) -> void:
	_toast("%s - coming in Step %d" % [what, step])


func _toast(msg: String, secs: float = 1.5) -> void:
	_toast_label.text = msg
	if _toast_tween != null and _toast_tween.is_valid():
		_toast_tween.kill()
	_toast_panel.modulate.a = 1.0
	_toast_tween = create_tween()
	_toast_tween.tween_interval(secs)
	_toast_tween.tween_property(_toast_panel, "modulate:a", 0.0, 0.4)


# ------------------------------------------------------------------ menu / dialog / overlay

func _build_menu_and_dialog() -> void:
	_menu = PopupMenu.new()
	_menu.add_item("New (empty)", 2)
	_menu.add_item("Open WAV file...", 0)
	_menu.add_item("Load demo tone", 1)
	_menu.id_pressed.connect(_on_menu_id)
	add_child(_menu)

	_file_dialog = FileDialog.new()
	_file_dialog.access = FileDialog.ACCESS_FILESYSTEM
	_file_dialog.use_native_dialog = true
	_file_dialog.filters = PackedStringArray(["*.wav ; WAV audio"])
	_file_dialog.file_selected.connect(_on_file_selected)
	add_child(_file_dialog)


func _build_overlay() -> void:
	_overlay = ColorRect.new()
	(_overlay as ColorRect).color = Color(0.03, 0.02, 0.10, 0.80)
	_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	_overlay.visible = false
	add_child(_overlay)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_overlay.add_child(center)

	var panel := PanelContainer.new()
	center.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 16)
	v.custom_minimum_size = Vector2(420, 0)
	panel.add_child(v)
	_overlay_label = _label("Loading...")
	_overlay_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(_overlay_label)
	_bar = ProgressBar.new()
	_bar.show_percentage = false
	_bar.custom_minimum_size = Vector2(0, 20)
	v.add_child(_bar)


func _on_open_pressed(btn: Button) -> void:
	if _recorder.recording:
		_toast("Stop recording first")
		return
	var r := btn.get_global_rect()
	_menu.popup_on_parent(Rect2i(Vector2i(int(r.position.x), int(r.end.y) + 6), Vector2i.ZERO))


func _on_menu_id(id: int) -> void:
	if id == 2:
		_new_empty_pressed()
	elif id == 0:
		_file_mode = "open"
		_file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
		_file_dialog.title = "Open WAV"
		_file_dialog.popup_centered_ratio(0.9)
	elif id == 1:
		_set_doc(WavIO.make_demo())


func _new_empty_pressed() -> void:
	if _recorder.recording:
		_toast("Stop recording first")
		return
	if _thread != null and _thread.is_started():
		_toast("Busy, please wait")
		return
	if _doc == null or _doc.length() == 0:
		_new_empty()
		return
	if _confirm == null:
		_confirm = ConfirmationDialog.new()
		_confirm.title = "New (empty)"
		_confirm.dialog_text = "Discard the current audio and start a new empty one?\nUnsaved audio will be lost."
		_confirm.ok_button_text = "Discard"
		_confirm.cancel_button_text = "Cancel"
		_confirm.confirmed.connect(_new_empty)
		add_child(_confirm)
	_confirm.popup_centered()


func _new_empty() -> void:
	var d = AudioDocScript.new()
	var rate := int(AudioServer.get_mix_rate())
	if rate <= 0:
		rate = FALLBACK_RATE
	d.rate = rate
	d.is_mono = false
	d.name = "Untitled"
	d.build_peaks()
	_set_doc(d)
	_toast("New empty file, %d Hz" % rate)


func _on_save_pressed() -> void:
	if _recorder.recording:
		_toast("Stop recording first")
		return
	if _doc == null or _doc.length() == 0:
		_toast("Nothing to save yet")
		return
	_export.open(_doc)


func _build_export() -> void:
	_export = ExportDialog.new()
	add_child(_export)
	_export.accepted.connect(_on_export_accepted)
	_export.message.connect(func(m: String): _toast(m))


func _on_export_accepted(fmt: Dictionary) -> void:
	_pending_fmt = fmt
	_file_mode = "save"
	_file_dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE
	_file_dialog.title = "Save WAV"
	_file_dialog.current_file = "%s.wav" % _doc.name
	_file_dialog.popup_centered_ratio(0.9)


func _on_file_selected(path: String) -> void:
	if _file_mode == "open":
		_start_job("load", [path])
	else:
		if not path.to_lower().ends_with(".wav"):
			path += ".wav"
		_start_job("save", [path, _doc, _pending_fmt])


func _on_files_dropped(files: PackedStringArray) -> void:
	if files.size() > 0 and files[0].to_lower().ends_with(".wav"):
		_start_job("load", [files[0]])


func _start_job(kind: String, args: Array) -> void:
	if _thread != null and _thread.is_started():
		_toast("Busy, please wait")
		return
	_stop_playback_ui()
	_job_kind = kind
	_progress = 0.0
	_bar.value = 0.0
	_overlay_label.text = {"load": "Loading...", "save": "Saving...", "merge": "Processing..."}.get(kind, "Working...")
	_overlay.visible = true
	_thread = Thread.new()
	_thread.start(_job_run.bind(kind, args))


func _set_progress(p: float) -> void:
	_progress = p


func _job_run(kind: String, args: Array) -> void:
	var cb := Callable(self, "_set_progress")
	if kind == "load":
		_job_result = WavIO.parse_wav(args[0], cb)
	elif kind == "merge":
		var base = args[0]
		var merged = base.inserted(args[1], args[2])
		_job_result = {"ok": true, "doc": merged, "end": clampi(args[2], 0, base.length()) + int(args[1].length() * float(base.rate) / float(args[1].rate))}
	else:
		var path: String = args[0]
		var d = args[1]
		var fmt: Dictionary = args[2]
		var err := WavIO.write_wav_fmt(path, d, fmt, cb)
		_job_result = {"ok": err == "", "error": err, "path": path, "fallback": ""}
		if err != "":
			var alt := "user://%s.wav" % d.name
			if WavIO.write_wav_fmt(alt, d, fmt, cb) == "":
				_job_result["fallback"] = alt
	_job_finished.call_deferred()


func _job_finished() -> void:
	_thread.wait_to_finish()
	_thread = null
	_overlay.visible = false
	var res := _job_result
	if _job_kind == "merge":
		_set_doc(res["doc"])
		_set_playhead(int(res["end"]))
		_wave.follow(int(res["end"]))
		_toast("Recording added")
	elif _job_kind == "load":
		if res.get("ok", false):
			_set_doc(res["doc"])
		else:
			_toast(str(res.get("error", "Load failed")).left(70), 3.5)
	else:
		if res.get("ok", false):
			_toast("Saved: %s" % str(res["path"]).get_file(), 2.5)
		elif str(res.get("fallback", "")) != "":
			_toast("Cannot write there. Saved in app storage:\n%s" % ProjectSettings.globalize_path(res["fallback"]), 6.0)
		else:
			_toast(str(res.get("error", "Save failed")).left(70), 3.5)


# ------------------------------------------------------------------ document / playback

func _set_doc(d) -> void:
	_stop_playback_ui()
	_doc = d
	_playhead = 0
	_play_origin = 0
	_wave.set_doc(d)
	_file_label.text = d.name
	var ch_text := "mono" if d.is_mono else "stereo"
	_fmt_label.text = "%d Hz | %s | %s" % [d.rate, ch_text, d.format_text()]
	_total_label.text = "/ " + _fmt_time(d.duration())
	_update_time()


@warning_ignore("integer_division")
func _fmt_time(sec: float) -> String:
	var ms := int(round(sec * 1000.0))
	return "%02d:%02d.%03d" % [ms / 60000, (ms / 1000) % 60, ms % 1000]


func _update_time() -> void:
	var rate: int = _doc.rate if _doc != null else 44100
	_time_label.text = _fmt_time(float(_playhead) / float(rate))


func _stop_playback_ui() -> void:
	_engine.stop()
	_btn_play.set_pressed_no_signal(false)


func _set_playhead(f: int) -> void:
	_playhead = f
	_wave.set_playhead(f)
	_update_time()


func _on_seek(frame: int) -> void:
	if _recorder.recording:
		return
	_play_origin = frame
	_set_playhead(frame)
	if _engine.playing:
		_engine.play(_doc, frame)


func _on_play_pressed() -> void:
	if _recorder.recording:
		_toast("Stop recording first")
		_btn_play.set_pressed_no_signal(false)
		return
	if _doc == null or _doc.length() == 0:
		_toast("Nothing to play - record or open a file")
		_btn_play.set_pressed_no_signal(false)
		return
	if _btn_play.button_pressed:
		var from := _playhead
		if from >= _doc.length() - 1:
			from = 0
		_play_origin = from
		_engine.loop = _btn_loop.button_pressed
		_engine.play(_doc, from)
	else:
		if _engine.playing:
			_set_playhead(_engine.current_frame())
			_engine.stop()


func _on_stop() -> void:
	if _doc == null:
		return
	_stop_playback_ui()
	_set_playhead(_play_origin)


func _on_to_start() -> void:
	if _doc == null:
		return
	_play_origin = 0
	_set_playhead(0)
	_wave.follow(0)
	if _engine.playing:
		_engine.play(_doc, 0)


func _on_to_end() -> void:
	if _doc == null:
		return
	_stop_playback_ui()
	_play_origin = maxi(0, _doc.length() - 1)
	_set_playhead(_doc.length())
	_wave.follow(_doc.length())


func _on_loop_pressed() -> void:
	_engine.loop = _btn_loop.button_pressed


func _on_play_finished() -> void:
	_btn_play.set_pressed_no_signal(false)
	if _doc != null:
		_set_playhead(_doc.length())


func _process(_delta: float) -> void:
	if _overlay != null and _overlay.visible:
		_bar.value = _progress * 100.0
	if _engine != null and _engine.playing:
		var f: int = _engine.current_frame()
		_set_playhead(f)
		_wave.follow(f)


# ------------------------------------------------------------------ recording

func _build_choice() -> void:
	_choice = ColorRect.new()
	(_choice as ColorRect).color = Color(0.03, 0.02, 0.10, 0.80)
	_choice.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_choice.mouse_filter = Control.MOUSE_FILTER_STOP
	_choice.visible = false
	add_child(_choice)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_choice.add_child(center)
	var panel := PanelContainer.new()
	center.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	v.custom_minimum_size = Vector2(480, 0)
	panel.add_child(v)
	var t := _label("Where should the new recording go?")
	t.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(t)
	var opts := [["Append to end", "append", "AccentButton"], ["Insert at playhead", "insert", ""], ["Replace everything (new)", "new", ""], ["Cancel", "", ""]]
	for o in opts:
		var b := _text_button(o[0], o[2])
		b.custom_minimum_size = Vector2(0, 68)
		b.pressed.connect(_choice_pick.bind(o[1]))
		v.add_child(b)


func _choice_pick(mode: String) -> void:
	_choice.visible = false
	if mode == "":
		return
	_rec_mode = mode
	_begin_record_flow()


func _has_mic_permission() -> bool:
	if OS.get_name() != "Android":
		return true
	return "android.permission.RECORD_AUDIO" in OS.get_granted_permissions()


func _on_record_pressed() -> void:
	if _recorder.recording:
		_finish_recording()
		return
	_btn_rec.set_pressed_no_signal(false)
	if _thread != null and _thread.is_started():
		_toast("Busy, please wait")
		return
	_stop_playback_ui()
	if _doc != null and _doc.length() > 0:
		_choice.visible = true
	else:
		_rec_mode = "new"
		_begin_record_flow()


func _begin_record_flow() -> void:
	if not _has_mic_permission():
		_pending_rec = true
		_toast("Allow microphone access...", 3.0)
		OS.request_permission("RECORD_AUDIO")
		return
	_start_recording()


func _on_permission_result(permission: String, granted: bool) -> void:
	if not permission.ends_with("RECORD_AUDIO") or not _pending_rec:
		return
	_pending_rec = false
	if granted:
		_start_recording()
	else:
		_toast("Microphone permission denied", 3.5)


func _start_recording() -> void:
	_rec_at = _playhead
	_recorder.start()
	_btn_rec.set_pressed_no_signal(true)
	_meter.reset()
	_tab_buttons[2].button_pressed = true
	_wave.set_live(true)
	_wave.set_doc(_recorder.doc)
	_wave.live_update()
	_total_label.text = "REC"
	_file_label.text = _recorder.doc.name
	var ch_name := "stereo" if _recorder.channels == 2 else "mono"
	_fmt_label.text = "%d Hz | %s | %s" % [_recorder.doc.rate, ch_name, "native" if _recorder.native_active else "16-bit"]
	var mic_rate := int(AudioServer.get_input_mix_rate())
	var rec_rate: int = _recorder.doc.rate
	if _recorder.native_active:
		_rec_status.text = "Advanced recording at %d Hz, %s (Android may still resample inside the phone)" % [rec_rate, ch_name]
	else:
		_rec_status.text = "Recording at %d Hz" % rec_rate if mic_rate == rec_rate or mic_rate <= 0 else "Mic %d Hz, recording at %d Hz" % [mic_rate, rec_rate]
	if _recorder.note != "":
		_rec_status.text += "\n" + _recorder.note
		_toast(_recorder.note, 4.0)
	_set_playhead(0)


func _on_rec_updated(peak: float) -> void:
	_meter.set_level(peak)
	var d = _recorder.doc
	if d == null:
		return
	_wave.live_update()
	_playhead = d.length()
	_wave.set_playhead(_playhead)
	_time_label.text = _fmt_time(float(_playhead) / float(d.rate))
	_rec_ui_t += get_process_delta_time()
	if _rec_ui_t > 0.1:
		_rec_ui_t = 0.0
		var db: float = _meter.peak_db()
		var clip := "   CLIP!" if db > -0.5 else ""
		_rec_status.text = "Recording  %s  |  %d Hz %s  |  peak %.1f dB%s" % [_fmt_time(_recorder.elapsed_sec()), d.rate, "stereo" if _recorder.channels == 2 else "mono", db, clip]


## Options of the native Android recorder (rate / channels / source). Hidden text-only note when the plugin is missing.
func _build_native_options(page: VBoxContainer) -> void:
	if not _recorder.native_available():
		var n := _label("Advanced recorder: not in this build (the standard recorder is used: system rate, mono).", "DimLabel")
		n.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		n.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		page.add_child(n)
		return
	var g := GridContainer.new()
	g.columns = 2
	g.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	g.add_theme_constant_override("h_separation", 12)
	g.add_theme_constant_override("v_separation", 8)
	page.add_child(g)
	var engine := _option_row(g, "Recorder", ["Advanced (choose rate / stereo)", "Standard (system rate, mono)"], 0)
	engine.item_selected.connect(func(i: int): _recorder.use_native = (i == 0))
	var rates := [44100, 48000, 96000, 192000]
	var rate_opt := _option_row(g, "Rate", ["44100 Hz", "48000 Hz", "96000 Hz", "192000 Hz"], 1)
	rate_opt.item_selected.connect(func(i: int): _recorder.native_rate = rates[i])
	var ch_opt := _option_row(g, "Channels", ["Mono", "Stereo"], 1)
	ch_opt.item_selected.connect(func(i: int): _recorder.native_channels = i + 1)
	var src_opt := _option_row(g, "Source", ["Microphone", "Unprocessed (raw)", "Voice recognition", "Camcorder", "Voice communication", "Voice performance (low latency)"], 0)
	src_opt.item_selected.connect(func(i: int): _recorder.native_source = i)
	var probe := _text_button("What does this phone accept?")
	probe.custom_minimum_size = Vector2(0, 64)
	probe.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	probe.pressed.connect(func(): _rec_status.text = _recorder.native_probe())
	page.add_child(probe)


func _option_row(grid: GridContainer, title: String, items: Array, selected: int) -> OptionButton:
	grid.add_child(_label(title, "DimLabel"))
	var o := OptionButton.new()
	o.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	o.custom_minimum_size = Vector2(0, 60)
	for it in items:
		o.add_item(it)
	o.select(selected)
	grid.add_child(o)
	return o


## Idle text of the Record tab: diagnostics about the audio rates Godot really runs at on this device.
func _idle_rec_text() -> String:
	var driver := ""
	if AudioServer.has_method("get_driver_name"):
		driver = str(AudioServer.call("get_driver_name"))
	return "Press the red Record button.\nEngine mix rate: %d Hz | Mic input: %d Hz\nOutput latency: %.0f ms | Driver: %s | Input device: %s\nProject setting: %s Hz" % [
		int(AudioServer.get_mix_rate()), int(AudioServer.get_input_mix_rate()),
		AudioServer.get_output_latency() * 1000.0, driver if driver != "" else "?",
		AudioServer.input_device, str(ProjectSettings.get_setting("audio/driver/mix_rate", "?"))]


func _on_rec_limit() -> void:
	_toast("Recording time limit reached", 3.0)
	_finish_recording()


func _on_rec_no_audio() -> void:
	_rec_status.text = "No sound from the microphone yet. Check the permission and that no other app is using the mic."
	_toast("No audio from microphone", 3.5)


func _finish_recording() -> void:
	var rec = _recorder.stop()
	_btn_rec.set_pressed_no_signal(false)
	_wave.set_live(false)
	if rec == null:
		_toast("Nothing recorded")
		if _doc != null:
			_wave.set_doc(_doc)
			_set_doc(_doc)
		else:
			_wave.set_doc(null)
		return
	_rec_status.text = "Recorded %s\n%s" % [_fmt_time(rec.duration()), _idle_rec_text().get_slice("\n", 1)]
	if _doc == null or _rec_mode == "new":
		_set_doc(rec)
		_toast("Recorded %s" % _fmt_time(rec.duration()))
	else:
		var at: int = _doc.length() if _rec_mode == "append" else _rec_at
		_start_job("merge", [_doc, rec, at])


# ------------------------------------------------------------------ responsive layout

func _on_window_resized() -> void:
	var win := get_window()
	var land := win.size.x > win.size.y
	var base := BASE_LANDSCAPE if land else BASE_PORTRAIT
	if win.content_scale_size != base:
		win.content_scale_size = base
	if land != _landscape or not _layout_ready:
		_landscape = land
		_layout_ready = true
		_apply_layout()
	_apply_safe_area()


func _apply_layout() -> void:
	_body.vertical = not _landscape
	if _landscape:
		_tabs_panel.custom_minimum_size = Vector2(470, 0)
		_tabs_panel.size_flags_horizontal = Control.SIZE_FILL
		_tabs_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
		_wave.custom_minimum_size = Vector2(0, 150)
	else:
		_tabs_panel.custom_minimum_size = Vector2(0, 330)
		_tabs_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_tabs_panel.size_flags_vertical = Control.SIZE_FILL
		_wave.custom_minimum_size = Vector2(0, 240)
	for g in _tab_grids:
		g.columns = 2 if _landscape else 3


func _apply_safe_area() -> void:
	# Keep the UI out of notches / status bar / navigation bar.
	var left := 0.0
	var top := 0.0
	var right := 0.0
	var bottom := 0.0
	var screen := DisplayServer.screen_get_size()
	var safe: Rect2i = DisplayServer.get_display_safe_area()
	var win_px := get_window().size
	if screen.x > 0 and screen.y > 0 and safe.size.x > 0 and safe.size.y > 0 and win_px.x > 0 and win_px.y > 0:
		var sx := get_viewport_rect().size.x / float(win_px.x)
		var sy := get_viewport_rect().size.y / float(win_px.y)
		left = maxf(0.0, float(safe.position.x)) * sx
		top = maxf(0.0, float(safe.position.y)) * sy
		right = maxf(0.0, float(screen.x - (safe.position.x + safe.size.x))) * sx
		bottom = maxf(0.0, float(screen.y - (safe.position.y + safe.size.y))) * sy
	_export.set_insets(left, top, right, bottom)
	_margin.add_theme_constant_override("margin_left", PAD + int(left))
	_margin.add_theme_constant_override("margin_top", PAD + int(top))
	_margin.add_theme_constant_override("margin_right", PAD + int(right))
	_margin.add_theme_constant_override("margin_bottom", PAD + int(bottom))
