extends RefCounted
## Builds the whole app Theme in code (no .tres files).

const P = preload("res://scripts/palette.gd")


static func box(bg: Color, radius: int = 16, border: Color = Color(0, 0, 0, 0), border_w: int = 0, pad_h: int = 18, pad_v: int = 12) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	s.set_border_width_all(border_w)
	s.border_color = border
	s.content_margin_left = pad_h
	s.content_margin_right = pad_h
	s.content_margin_top = pad_v
	s.content_margin_bottom = pad_v
	s.anti_aliasing = true
	return s


static func _btn(t: Theme, type: String, normal: Color, hover: Color, pressed: Color, border: Color, font_col: Color, radius: int, pad_h: int, pad_v: int, font_size: int = 24, border_w: int = 2) -> void:
	t.set_stylebox("normal", type, box(normal, radius, border, border_w, pad_h, pad_v))
	t.set_stylebox("hover", type, box(hover, radius, border, border_w, pad_h, pad_v))
	t.set_stylebox("pressed", type, box(pressed, radius, border, border_w, pad_h, pad_v))
	t.set_stylebox("hover_pressed", type, box(pressed.lightened(0.08), radius, border, border_w, pad_h, pad_v))
	t.set_stylebox("disabled", type, box(Color(normal.r, normal.g, normal.b, normal.a * 0.45), radius, Color(border.r, border.g, border.b, border.a * 0.4), border_w, pad_h, pad_v))
	t.set_stylebox("focus", type, StyleBoxEmpty.new())
	t.set_color("font_color", type, font_col)
	t.set_color("font_hover_color", type, font_col)
	t.set_color("font_pressed_color", type, Color.WHITE)
	t.set_color("font_hover_pressed_color", type, Color.WHITE)
	t.set_color("font_focus_color", type, font_col)
	t.set_color("font_disabled_color", type, P.TEXT_DIM.darkened(0.4))
	t.set_font_size("font_size", type, font_size)


static func _variation(t: Theme, name: String, base: String) -> void:
	t.set_type_variation(name, base)


static func _seg_dist(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ab := b - a
	var t := clampf((p - a).dot(ab) / ab.length_squared(), 0.0, 1.0)
	return p.distance_to(a + ab * t)


## Radio button icon drawn in code (clearly visible on dark backgrounds).
static func _radio_tex(checked: bool, px: int = 34) -> ImageTexture:
	var img := Image.create(px, px, false, Image.FORMAT_RGBA8)
	var c := Vector2((px - 1) * 0.5, (px - 1) * 0.5)
	var r_out := px * 0.5 - 2.0
	var r_in := r_out - 3.0
	var r_dot := r_out - 8.0
	var ring := Color.WHITE if checked else Color(0.76, 0.74, 0.96)
	for y in px:
		for x in px:
			var d := Vector2(x, y).distance_to(c)
			var a_ring := clampf(r_out - d + 0.5, 0.0, 1.0) * clampf(d - r_in + 0.5, 0.0, 1.0)
			var a_dot := clampf(r_dot - d + 0.5, 0.0, 1.0) if checked else 0.0
			img.set_pixel(x, y, Color(ring.r, ring.g, ring.b, maxf(a_ring, a_dot)))
	return ImageTexture.create_from_image(img)


## Check box icon: rounded outline, or filled violet with a white tick.
static func _check_tex(checked: bool, px: int = 34) -> ImageTexture:
	var img := Image.create(px, px, false, Image.FORMAT_RGBA8)
	var c := Vector2((px - 1) * 0.5, (px - 1) * 0.5)
	var rad := 8.0
	var half := Vector2(px * 0.5 - 3.0, px * 0.5 - 3.0)
	var k := float(px) / 34.0
	var s1a := Vector2(9.0, 17.5) * k
	var s1b := Vector2(14.5, 23.0) * k
	var s2b := Vector2(25.0, 11.0) * k
	for y in px:
		for x in px:
			var p := Vector2(x, y)
			var q := (p - c).abs() - (half - Vector2(rad, rad))
			var sd := Vector2(maxf(q.x, 0.0), maxf(q.y, 0.0)).length() + minf(maxf(q.x, q.y), 0.0) - rad
			var fill_a := clampf(0.5 - sd, 0.0, 1.0)
			if checked:
				var chk := clampf(2.6 - minf(_seg_dist(p, s1a, s1b), _seg_dist(p, s1b, s2b)) + 0.5, 0.0, 1.0)
				var col := P.VIOLET.lerp(Color.WHITE, chk)
				img.set_pixel(x, y, Color(col.r, col.g, col.b, fill_a))
			else:
				var ring_a := fill_a * clampf(sd + 3.5, 0.0, 1.0)
				img.set_pixel(x, y, Color(0.76, 0.74, 0.96, ring_a))
	return ImageTexture.create_from_image(img)


static func _chevron_tex(px: int = 26) -> ImageTexture:
	var img := Image.create(px, px, false, Image.FORMAT_RGBA8)
	var k := float(px) / 26.0
	var a := Vector2(5.0, 9.0) * k
	var m := Vector2(13.0, 17.0) * k
	var b := Vector2(21.0, 9.0) * k
	for y in px:
		for x in px:
			var p := Vector2(x, y)
			var d := minf(_seg_dist(p, a, m), _seg_dist(p, m, b))
			img.set_pixel(x, y, Color(0.93, 0.94, 1.0, clampf(2.2 - d + 0.5, 0.0, 1.0)))
	return ImageTexture.create_from_image(img)


static func build() -> Theme:
	var t := Theme.new()
	t.default_font_size = 26

	# ---- Fonts ----
	var mono := SystemFont.new()
	mono.font_names = PackedStringArray(["Roboto Mono", "Droid Sans Mono", "DejaVu Sans Mono", "monospace"])
	var fb: Array[Font] = [ThemeDB.fallback_font]
	mono.fallbacks = fb

	# ---- Label ----
	t.set_color("font_color", "Label", P.TEXT)
	t.set_font_size("font_size", "Label", 26)

	_variation(t, "DimLabel", "Label")
	t.set_color("font_color", "DimLabel", P.TEXT_DIM)
	t.set_font_size("font_size", "DimLabel", 22)

	_variation(t, "TitleLabel", "Label")
	t.set_color("font_color", "TitleLabel", Color.WHITE)
	t.set_font_size("font_size", "TitleLabel", 30)

	_variation(t, "TimeLabel", "Label")
	t.set_color("font_color", "TimeLabel", Color.WHITE)
	t.set_font_size("font_size", "TimeLabel", 56)
	t.set_font("font", "TimeLabel", mono)

	_variation(t, "ToastLabel", "Label")
	t.set_color("font_color", "ToastLabel", Color.WHITE)
	t.set_font_size("font_size", "ToastLabel", 24)

	# ---- Panels ----
	t.set_stylebox("panel", "PanelContainer", box(P.SURFACE, 20, P.BORDER, 2, 14, 12))

	_variation(t, "Header", "PanelContainer")
	t.set_stylebox("panel", "Header", box(P.SURFACE, 22, P.BORDER, 2, 14, 10))

	_variation(t, "WaveCard", "PanelContainer")
	t.set_stylebox("panel", "WaveCard", box(P.BG_DEEP, 18, P.BORDER, 2, 4, 4))

	_variation(t, "Toast", "PanelContainer")
	t.set_stylebox("panel", "Toast", box(Color(0.09, 0.07, 0.26, 0.96), 40, P.VIOLET, 2, 28, 12))

	# ---- Buttons ----
	_btn(t, "Button", P.SURFACE2, P.SURFACE2.lightened(0.10), P.INDIGO, P.BORDER, P.TEXT, 16, 18, 12)

	_variation(t, "AccentButton", "Button")
	_btn(t, "AccentButton", P.VIOLET, P.VIOLET_LIGHT, P.INDIGO_LIGHT, P.VIOLET_LIGHT, Color.WHITE, 16, 18, 12)

	_variation(t, "ToolButton", "Button")
	_btn(t, "ToolButton", P.SURFACE2, P.SURFACE2.lightened(0.10), P.VIOLET.darkened(0.25), P.BORDER, P.TEXT, 16, 8, 8)

	_variation(t, "TabButton", "Button")
	_btn(t, "TabButton", P.BG_DEEP, P.SURFACE2, P.INDIGO, P.BORDER, P.TEXT_DIM, 14, 10, 12, 24, 2)

	_variation(t, "RoundButton", "Button")
	_btn(t, "RoundButton", P.SURFACE2, P.SURFACE2.lightened(0.10), P.VIOLET.darkened(0.25), P.BORDER, P.TEXT, 100, 4, 4)

	_variation(t, "AccentRound", "Button")
	_btn(t, "AccentRound", P.VIOLET, P.VIOLET_LIGHT, P.INDIGO, P.VIOLET_LIGHT, Color.WHITE, 100, 4, 4)

	_variation(t, "DangerRound", "Button")
	_btn(t, "DangerRound", P.DANGER.darkened(0.25), P.DANGER.darkened(0.1), P.DANGER, P.DANGER, Color.WHITE, 100, 4, 4)

	# ---- Scroll bars (thin, violet) ----
	for st in ["VScrollBar", "HScrollBar"]:
		var track := box(Color(1, 1, 1, 0.07), 7, Color(0, 0, 0, 0), 0, 7, 7)
		t.set_stylebox("scroll", st, track)
		t.set_stylebox("scroll_focus", st, track)
		t.set_stylebox("grabber", st, box(P.VIOLET, 7, Color(0, 0, 0, 0), 0, 7, 7))
		t.set_stylebox("grabber_highlight", st, box(P.VIOLET_LIGHT, 7, Color(0, 0, 0, 0), 0, 7, 7))
		t.set_stylebox("grabber_pressed", st, box(P.VIOLET_LIGHT, 7, Color(0, 0, 0, 0), 0, 7, 7))

	# ---- OptionButton (drop-down) ----
	_btn(t, "OptionButton", P.SURFACE2, P.SURFACE2.lightened(0.10), P.INDIGO, P.BORDER, P.TEXT, 14, 16, 10, 26)
	t.set_constant("h_separation", "OptionButton", 10)
	t.set_icon("arrow", "OptionButton", _chevron_tex())
	t.set_constant("arrow_margin", "OptionButton", 14)

	# ---- Text input (SpinBox uses this) ----
	t.set_stylebox("normal", "LineEdit", box(P.BG_DEEP, 12, P.BORDER, 2, 14, 10))
	t.set_stylebox("focus", "LineEdit", box(P.BG_DEEP, 12, P.VIOLET_LIGHT, 2, 14, 10))
	t.set_stylebox("read_only", "LineEdit", box(P.BG_DEEP, 12, P.BORDER, 2, 14, 10))
	t.set_color("font_color", "LineEdit", P.TEXT)
	t.set_color("caret_color", "LineEdit", P.VIOLET_LIGHT)
	t.set_color("selection_color", "LineEdit", Color(P.VIOLET.r, P.VIOLET.g, P.VIOLET.b, 0.5))
	t.set_font_size("font_size", "LineEdit", 26)

	# ---- Radio / check rows used by the export list ----
	_variation(t, "ListRow", "CheckBox")
	var row_clear := box(Color(0, 0, 0, 0), 6, Color(0, 0, 0, 0), 0, 12, 14)
	t.set_stylebox("normal", "ListRow", row_clear)
	t.set_stylebox("hover", "ListRow", box(P.SURFACE2, 6, Color(0, 0, 0, 0), 0, 12, 14))
	t.set_stylebox("pressed", "ListRow", box(P.INDIGO, 6, Color(0, 0, 0, 0), 0, 12, 14))
	t.set_stylebox("hover_pressed", "ListRow", box(P.INDIGO_LIGHT, 6, Color(0, 0, 0, 0), 0, 12, 14))
	t.set_stylebox("disabled", "ListRow", row_clear)
	t.set_stylebox("focus", "ListRow", StyleBoxEmpty.new())
	for c in ["font_color", "font_hover_color", "font_focus_color"]:
		t.set_color(c, "ListRow", P.TEXT)
	for c in ["font_pressed_color", "font_hover_pressed_color"]:
		t.set_color(c, "ListRow", Color.WHITE)
	t.set_font_size("font_size", "ListRow", 26)
	t.set_constant("h_separation", "ListRow", 18)
	t.set_icon("radio_checked", "ListRow", _radio_tex(true))
	t.set_icon("radio_unchecked", "ListRow", _radio_tex(false))

	t.set_stylebox("normal", "CheckBox", box(Color(0, 0, 0, 0), 8, Color(0, 0, 0, 0), 0, 8, 10))
	t.set_stylebox("hover", "CheckBox", box(P.SURFACE2, 8, Color(0, 0, 0, 0), 0, 8, 10))
	t.set_stylebox("pressed", "CheckBox", box(Color(0, 0, 0, 0), 8, Color(0, 0, 0, 0), 0, 8, 10))
	t.set_stylebox("hover_pressed", "CheckBox", box(P.SURFACE2, 8, Color(0, 0, 0, 0), 0, 8, 10))
	t.set_stylebox("focus", "CheckBox", StyleBoxEmpty.new())
	t.set_color("font_color", "CheckBox", P.TEXT)
	t.set_color("font_hover_color", "CheckBox", P.TEXT)
	t.set_color("font_pressed_color", "CheckBox", P.TEXT)
	t.set_color("font_hover_pressed_color", "CheckBox", P.TEXT)
	t.set_font_size("font_size", "CheckBox", 24)
	t.set_constant("h_separation", "CheckBox", 14)
	t.set_icon("checked", "CheckBox", _check_tex(true))
	t.set_icon("unchecked", "CheckBox", _check_tex(false))

	# ---- Collapsible section header ----
	_variation(t, "FilterHeader", "Button")
	_btn(t, "FilterHeader", P.SURFACE2, P.SURFACE2.lightened(0.08), P.SURFACE2, P.BORDER, P.TEXT, 12, 18, 16, 28)

	# ---- Popup menu ----
	t.set_stylebox("panel", "PopupMenu", box(P.SURFACE2, 16, P.VIOLET, 2, 10, 10))
	t.set_stylebox("hover", "PopupMenu", box(P.INDIGO, 10, Color(0, 0, 0, 0), 0, 8, 8))
	t.set_color("font_color", "PopupMenu", P.TEXT)
	t.set_color("font_hover_color", "PopupMenu", Color.WHITE)
	t.set_font_size("font_size", "PopupMenu", 26)
	t.set_constant("v_separation", "PopupMenu", 24)
	t.set_constant("item_start_padding", "PopupMenu", 16)
	t.set_constant("item_end_padding", "PopupMenu", 16)

	# ---- Progress bar ----
	t.set_stylebox("background", "ProgressBar", box(P.BG_DEEP, 12, P.BORDER, 2, 0, 0))
	t.set_stylebox("fill", "ProgressBar", box(P.VIOLET, 12, Color(0, 0, 0, 0), 0, 0, 0))

	return t
