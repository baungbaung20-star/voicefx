extends Node
## Playback engine. Streams the document's float samples to an AudioStreamGenerator
## in small chunks, so seek / pause / loop are instant and the playhead is exact.

signal finished

const FILL_SEC := 0.25
const CHUNK := 2048

var doc = null
var playing := false
var loop := false

var _player: AudioStreamPlayer
var _gen: AudioStreamGenerator
var _pb: AudioStreamGeneratorPlayback
var _cap := 1
var _pos := 0          # next frame to push
var _exhausted := false


func _ready() -> void:
	_player = AudioStreamPlayer.new()
	add_child(_player)


func play(d, from_frame: int) -> void:
	stop()
	doc = d
	if doc == null or doc.length() == 0:
		return
	_gen = AudioStreamGenerator.new()
	_gen.mix_rate = minf(float(doc.rate), 192000.0)
	_gen.buffer_length = 0.4
	_player.stream = _gen
	_player.play()
	_pb = _player.get_stream_playback() as AudioStreamGeneratorPlayback
	_cap = maxi(1, _pb.get_frames_available())
	_pos = clampi(from_frame, 0, doc.length() - 1)
	_exhausted = false
	playing = true
	_pump()


func stop() -> void:
	playing = false
	_exhausted = false
	if _player != null:
		_player.stop()
	_pb = null


## Current audible position in frames.
func current_frame() -> int:
	if doc == null:
		return 0
	if _pb == null:
		return clampi(_pos, 0, doc.length())
	var buffered := _cap - _pb.get_frames_available()
	var f := _pos - buffered
	if f < 0:
		f = f + doc.length() if loop else 0
	return clampi(f, 0, doc.length())


func _process(_delta: float) -> void:
	if not playing or _pb == null:
		return
	_pump()
	if _exhausted and _pb.get_frames_available() >= _cap - 64:
		var end_frame: int = doc.length()
		stop()
		_pos = end_frame
		finished.emit()


func _pump() -> void:
	var n_total: int = doc.length()
	var want := int(FILL_SEC * float(doc.rate)) - (_cap - _pb.get_frames_available())
	var avail := mini(want, _pb.get_frames_available())
	var l: PackedFloat32Array = doc.left
	var r: PackedFloat32Array = doc.right
	while avail > 0 and not _exhausted:
		var remain := n_total - _pos
		if remain <= 0:
			if loop:
				_pos = 0
				remain = n_total
			else:
				_exhausted = true
				break
		var cnt := mini(mini(avail, CHUNK), remain)
		var frames := PackedVector2Array()
		frames.resize(cnt)
		var p := _pos
		for i in cnt:
			frames[i] = Vector2(l[p + i], r[p + i])
		_pb.push_buffer(frames)
		_pos += cnt
		avail -= cnt
