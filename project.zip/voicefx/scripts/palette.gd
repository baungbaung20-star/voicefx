extends RefCounted
## Indigo + Violet colour palette (constants only).

const BG := Color("0E0B1F")
const BG_DEEP := Color("0A0818")
const SURFACE := Color("17133A")
const SURFACE2 := Color("221C54")
const BORDER := Color("342C80")

const INDIGO := Color("4F46E5")
const INDIGO_LIGHT := Color("6366F1")
const VIOLET := Color("8B5CF6")
const VIOLET_LIGHT := Color("A78BFA")

const TEXT := Color("EEF0FF")
const TEXT_DIM := Color("9A97C9")

const DANGER := Color("F43F5E")
const OK := Color("34D399")

const WAVE_L := Color("818CF8")
const WAVE_R := Color("C4B5FD")
