extends RefCounted
## In-memory audio document.
## Always holds two float channels (a mono file keeps the same array in both),
## plus a min/max "peak pyramid" so the waveform can be drawn fast at any zoom.

const BLOCK0 := 64
const LEVEL_FACTOR := 4

var rate: int = 44100
var left := PackedFloat32Array()
var right := PackedFloat32Array()
var is_mono := false
var src_bits := 16
## WAV format tag of the source: 1 PCM, 3 float, 6 A-law, 7 mu-law
var src_tag := 1
var name := "untitled"
## Per channel: Array of Dictionary { block:int, mn:PackedFloat32Array, mx:PackedFloat32Array }
var peaks: Array = [[], []]


func length() -> int:
	return left.size()


func duration() -> float:
	return float(left.size()) / float(rate) if rate > 0 else 0.0


func channel(i: int) -> PackedFloat32Array:
	return left if (i == 0 or is_mono) else right


# ------------------------------------------------------------------ peaks

func build_peaks(progress: Callable = Callable(), p0: float = 0.0, p1: float = 1.0) -> void:
	peaks = [[], []]
	if is_mono:
		var lv := _levels_for(left, progress, p0, p1)
		peaks[0] = lv
		peaks[1] = lv
	else:
		var mid := (p0 + p1) * 0.5
		peaks[0] = _levels_for(left, progress, p0, mid)
		peaks[1] = _levels_for(right, progress, mid, p1)


@warning_ignore("integer_division")
func _levels_for(a: PackedFloat32Array, progress: Callable, p0: float, p1: float) -> Array:
	var levels: Array = []
	var n := a.size()
	if n == 0:
		return levels
	var nb := (n + BLOCK0 - 1) / BLOCK0
	var mn := PackedFloat32Array()
	var mx := PackedFloat32Array()
	mn.resize(nb)
	mx.resize(nb)
	for b in nb:
		var s := b * BLOCK0
		var e := mini(s + BLOCK0, n)
		var lo := a[s]
		var hi := lo
		for i in range(s + 1, e):
			var v := a[i]
			if v < lo:
				lo = v
			elif v > hi:
				hi = v
		mn[b] = lo
		mx[b] = hi
		if (b & 0x3FFF) == 0 and progress.is_valid():
			progress.call(p0 + (p1 - p0) * float(b) / float(nb))
	levels.append({"block": BLOCK0, "mn": mn, "mx": mx})

	_add_upper(levels)
	if progress.is_valid():
		progress.call(p1)
	return levels


## Returns interleaved [min0, max0, min1, max1, ...] for `cols` pixel columns.
@warning_ignore("integer_division")
func column_peaks(ch: int, start: float, spp: float, cols: int) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	out.resize(maxi(cols, 0) * 2)
	var a := channel(ch)
	var n := a.size()
	if n == 0 or cols <= 0:
		return out
	var levels: Array = peaks[ch]
	if levels.is_empty() and spp > 256.0:
		return out
	var lv := -1
	for k in levels.size():
		if float(levels[k]["block"]) <= spp:
			lv = k
	if lv < 0:
		for c in cols:
			var s0 := clampi(int(floor(start + c * spp)), 0, n - 1)
			var s1 := clampi(int(ceil(start + (c + 1) * spp)), s0 + 1, n)
			var lo := a[s0]
			var hi := lo
			for i in range(s0 + 1, s1):
				var v := a[i]
				if v < lo:
					lo = v
				elif v > hi:
					hi = v
			out[c * 2] = lo
			out[c * 2 + 1] = hi
	else:
		var blk: int = levels[lv]["block"]
		var mn: PackedFloat32Array = levels[lv]["mn"]
		var mx: PackedFloat32Array = levels[lv]["mx"]
		var nb := mn.size()
		for c in cols:
			var s0 := clampi(int(floor(start + c * spp)), 0, n - 1)
			var s1 := clampi(int(ceil(start + (c + 1) * spp)), s0 + 1, n)
			var b0 := clampi(s0 / blk, 0, nb - 1)
			var b1 := clampi((s1 - 1) / blk, b0, nb - 1)
			var lo := mn[b0]
			var hi := mx[b0]
			for b in range(b0 + 1, b1 + 1):
				if mn[b] < lo:
					lo = mn[b]
				if mx[b] > hi:
					hi = mx[b]
			out[c * 2] = lo
			out[c * 2 + 1] = hi
	return out


## Builds the coarser pyramid levels on top of the last (finest) level.
@warning_ignore("integer_division")
func _add_upper(levels: Array) -> void:
	if levels.is_empty():
		return
	var last: Dictionary = levels[levels.size() - 1]
	var block: int = last["block"]
	var cur_mn: PackedFloat32Array = last["mn"]
	var cur_mx: PackedFloat32Array = last["mx"]
	while cur_mn.size() > 8:
		var cn := cur_mn.size()
		var nn := (cn + LEVEL_FACTOR - 1) / LEVEL_FACTOR
		var n_mn := PackedFloat32Array()
		var n_mx := PackedFloat32Array()
		n_mn.resize(nn)
		n_mx.resize(nn)
		for j in nn:
			var s2 := j * LEVEL_FACTOR
			var e2 := mini(s2 + LEVEL_FACTOR, cn)
			var lo2 := cur_mn[s2]
			var hi2 := cur_mx[s2]
			for k in range(s2 + 1, e2):
				if cur_mn[k] < lo2:
					lo2 = cur_mn[k]
				if cur_mx[k] > hi2:
					hi2 = cur_mx[k]
			n_mn[j] = lo2
			n_mx[j] = hi2
		block *= LEVEL_FACTOR
		levels.append({"block": block, "mn": n_mn, "mx": n_mx})
		cur_mn = n_mn
		cur_mx = n_mx


# ------------------------------------------------------------------ recording

func begin_recording(rate_hz: int) -> void:
	rate = rate_hz
	left = PackedFloat32Array()
	right = PackedFloat32Array()
	is_mono = true
	src_bits = 16
	var lv: Array = [{"block": BLOCK0, "mn": PackedFloat32Array(), "mx": PackedFloat32Array()}]
	peaks = [lv, lv]


## Appends mono samples and keeps the finest peak level up to date (cheap).
@warning_ignore("integer_division")
func append_mono(chunk: PackedFloat32Array) -> void:
	if chunk.is_empty():
		return
	var old := left.size()
	left.append_array(chunk)
	var n := left.size()
	var lv: Dictionary = peaks[0][0]
	var mn: PackedFloat32Array = lv["mn"]
	var mx: PackedFloat32Array = lv["mx"]
	lv["mn"] = PackedFloat32Array()
	lv["mx"] = PackedFloat32Array()
	var nb := (n + BLOCK0 - 1) / BLOCK0
	mn.resize(nb)
	mx.resize(nb)
	for b in range(old / BLOCK0, nb):
		var s := b * BLOCK0
		var e := mini(s + BLOCK0, n)
		var lo := left[s]
		var hi := lo
		for i in range(s + 1, e):
			var v := left[i]
			if v < lo:
				lo = v
			elif v > hi:
				hi = v
		mn[b] = lo
		mx[b] = hi
	lv["mn"] = mn
	lv["mx"] = mx


func finish_recording() -> void:
	right = left
	var lv: Array = peaks[0]
	while lv.size() > 1:
		lv.remove_at(lv.size() - 1)
	_add_upper(lv)
	peaks = [lv, lv]


# ------------------------------------------------------------------ editing helpers

## Sample-rate conversion. When lowering the rate an anti-alias low-pass
## (6th-order Butterworth, cutoff 0.42 x target rate) runs first, then cubic
## (Catmull-Rom) interpolation.
static func resample(a: PackedFloat32Array, from_rate: int, to_rate: int, antialias: bool = true, progress: Callable = Callable(), p0: float = 0.0, p1: float = 1.0) -> PackedFloat32Array:
	if from_rate == to_rate or a.is_empty():
		return a
	var src := a
	var mid := p0
	if antialias and to_rate < from_rate:
		mid = p0 + (p1 - p0) * 0.6
		src = lowpass(a, float(from_rate), 0.42 * float(to_rate), progress, p0, mid)
	var n := src.size()
	var ratio := float(from_rate) / float(to_rate)
	var n_out := int(float(n - 1) / ratio) + 1
	var padded := PackedFloat32Array()
	padded.append(src[0])
	padded.append_array(src)
	padded.append(src[n - 1])
	padded.append(src[n - 1])
	var out := PackedFloat32Array()
	out.resize(n_out)
	var p := 0.0
	for i in n_out:
		var i1 := int(p)
		var f := p - float(i1)
		p += ratio
		var y0 := padded[i1]
		var y1 := padded[i1 + 1]
		var y2 := padded[i1 + 2]
		var y3 := padded[i1 + 3]
		var c1 := 0.5 * (y2 - y0)
		var c2 := y0 - 2.5 * y1 + 2.0 * y2 - 0.5 * y3
		var c3 := 0.5 * (y3 - y0) + 1.5 * (y1 - y2)
		out[i] = ((c3 * f + c2) * f + c1) * f + y1
		if (i & 0x3FFFF) == 0 and progress.is_valid():
			progress.call(mid + (p1 - mid) * float(i) / float(n_out))
	return out


static func lowpass(a: PackedFloat32Array, fs: float, fc: float, progress: Callable = Callable(), p0: float = 0.0, p1: float = 1.0) -> PackedFloat32Array:
	# 6th-order Butterworth = 3 cascaded biquads (Q = 0.5176, 0.7071, 1.9319), run in ONE pass.
	var w0 := TAU * minf(fc, fs * 0.49) / fs
	var cw := cos(w0)
	var sw := sin(w0)
	var al1 := sw / (2.0 * 0.5176)
	var al2 := sw / (2.0 * 0.7071)
	var al3 := sw / (2.0 * 1.9319)
	var n0 := 1.0 + al1
	var b0a := (1.0 - cw) * 0.5 / n0
	var b1a := (1.0 - cw) / n0
	var a1a := -2.0 * cw / n0
	var a2a := (1.0 - al1) / n0
	n0 = 1.0 + al2
	var b0b := (1.0 - cw) * 0.5 / n0
	var b1b := (1.0 - cw) / n0
	var a1b := -2.0 * cw / n0
	var a2b := (1.0 - al2) / n0
	n0 = 1.0 + al3
	var b0c := (1.0 - cw) * 0.5 / n0
	var b1c := (1.0 - cw) / n0
	var a1c := -2.0 * cw / n0
	var a2c := (1.0 - al3) / n0
	var z1a := 0.0
	var z2a := 0.0
	var z1b := 0.0
	var z2b := 0.0
	var z1c := 0.0
	var z2c := 0.0
	var out := a.duplicate()
	var n := out.size()
	for i in n:
		var x := out[i]
		var y := b0a * x + z1a
		z1a = b1a * x - a1a * y + z2a
		z2a = b0a * x - a2a * y
		x = y
		y = b0b * x + z1b
		z1b = b1b * x - a1b * y + z2b
		z2b = b0b * x - a2b * y
		x = y
		y = b0c * x + z1c
		z1c = b1c * x - a1c * y + z2c
		z2c = b0c * x - a2c * y
		out[i] = y
		if (i & 0x3FFFF) == 0 and progress.is_valid():
			progress.call(p0 + (p1 - p0) * float(i) / float(n))
	return out


func format_text() -> String:
	match src_tag:
		3:
			return "float %d-bit" % src_bits
		6:
			return "A-Law"
		7:
			return "u-Law"
		_:
			return "%d-bit" % src_bits


## Returns a NEW doc with the mono recording `rec` inserted at frame `at`.
func inserted(rec, at: int):
	var r: PackedFloat32Array = resample(rec.left, rec.rate, rate)
	var rr: PackedFloat32Array = r if rec.is_mono else resample(rec.right, rec.rate, rate)
	var stereo: bool = (not is_mono) or (not rec.is_mono)
	at = clampi(at, 0, length())
	var d = get_script().new()
	d.rate = rate
	d.name = name
	d.src_bits = src_bits
	d.is_mono = not stereo
	var nl := left.slice(0, at)
	nl.append_array(r)
	nl.append_array(left.slice(at))
	d.left = nl
	if not stereo:
		d.right = nl
	else:
		var base_r: PackedFloat32Array = channel(1)
		var nr := base_r.slice(0, at)
		nr.append_array(rr)
		nr.append_array(base_r.slice(at))
		d.right = nr
	d.build_peaks()
	return d
