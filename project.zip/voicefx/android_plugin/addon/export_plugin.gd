@tool
extends EditorExportPlugin


func _get_name() -> String:
	return "VfxRecorderExport"


func _supports_platform(platform: EditorExportPlatform) -> bool:
	return platform is EditorExportPlatformAndroid


func _get_android_manifest_application_element_contents(_platform: EditorExportPlatform, _debug: bool) -> String:
	return '<meta-data android:name="org.godotengine.plugin.v2.VfxRecorder" android:value="com.voicefx.recorder.VfxRecorder" />'
