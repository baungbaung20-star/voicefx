@tool
extends EditorPlugin

const ExportPlugin = preload("res://addons/vfx_android/export_plugin.gd")
var _exp


func _enter_tree() -> void:
	_exp = ExportPlugin.new()
	add_export_plugin(_exp)


func _exit_tree() -> void:
	remove_export_plugin(_exp)
	_exp = null
