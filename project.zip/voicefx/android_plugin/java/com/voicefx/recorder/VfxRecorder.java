package com.voicefx.recorder;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import org.godotengine.godot.Godot;
import org.godotengine.godot.plugin.GodotPlugin;
import org.godotengine.godot.plugin.UsedByGodot;

import java.util.Arrays;

/**
 * Native microphone recorder for Voice FX Studio.
 * Uses android.media.AudioRecord directly, so the sample rate and the channel
 * count are chosen by the app instead of by Godot's mix rate.
 *
 * Godot side: Engine.get_singleton("VfxRecorder").
 * Samples are returned as interleaved float32 (-1..1).
 */
public class VfxRecorder extends GodotPlugin {
    private static final int MAX_FLOATS = 64 * 1024 * 1024; // safety cap for the pending queue

    private final Object lock = new Object();
    private AudioRecord record;
    private Thread thread;
    private volatile boolean running = false;
    private float[] pending = new float[0];
    private int pendingLen = 0;
    private int rate = 0;
    private int channels = 0;
    private String error = "";

    public VfxRecorder(Godot godot) {
        super(godot);
    }

    @Override
    public String getPluginName() {
        return "VfxRecorder";
    }

    private static int sourceFor(int code) {
        switch (code) {
            case 1: return MediaRecorder.AudioSource.UNPROCESSED;
            case 2: return MediaRecorder.AudioSource.VOICE_RECOGNITION;
            case 3: return MediaRecorder.AudioSource.CAMCORDER;
            case 4: return MediaRecorder.AudioSource.VOICE_COMMUNICATION;
            case 5: return MediaRecorder.AudioSource.VOICE_PERFORMANCE; // Android 10+; older phones fall back to MIC
            default: return MediaRecorder.AudioSource.MIC;
        }
    }

    private static int maskFor(int channelCount) {
        return channelCount >= 2 ? AudioFormat.CHANNEL_IN_STEREO : AudioFormat.CHANNEL_IN_MONO;
    }

    /** source: 0 = MIC, 1 = UNPROCESSED, 2 = VOICE_RECOGNITION, 3 = CAMCORDER, 4 = VOICE_COMMUNICATION, 5 = VOICE_PERFORMANCE. */
    @UsedByGodot
    public boolean start(int sampleRate, int channelCount, int source) {
        stop();
        error = "";
        try {
            Context ctx = getContext();
            if (ctx == null || ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                error = "RECORD_AUDIO permission is not granted";
                return false;
            }
            int ch = channelCount >= 2 ? 2 : 1;
            int mask = maskFor(ch);
            int minBytes = AudioRecord.getMinBufferSize(sampleRate, mask, AudioFormat.ENCODING_PCM_FLOAT);
            if (minBytes <= 0) {
                error = "Rate " + sampleRate + " Hz / " + ch + " ch is not supported (getMinBufferSize=" + minBytes + ")";
                return false;
            }
            int bytes = Math.max(minBytes * 2, sampleRate * ch * 4 / 2); // about 0.5 s
            AudioRecord r = null;
            int[] tries = new int[] { sourceFor(source), MediaRecorder.AudioSource.MIC };
            for (int src : tries) {
                try {
                    r = new AudioRecord.Builder()
                            .setAudioSource(src)
                            .setAudioFormat(new AudioFormat.Builder()
                                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                                    .setSampleRate(sampleRate)
                                    .setChannelMask(mask)
                                    .build())
                            .setBufferSizeInBytes(bytes)
                            .build();
                } catch (Exception e) {
                    r = null;
                    error = "AudioRecord build failed: " + e;
                }
                if (r != null && r.getState() == AudioRecord.STATE_INITIALIZED) {
                    break;
                }
                if (r != null) {
                    r.release();
                    r = null;
                }
            }
            if (r == null) {
                if (error.isEmpty()) {
                    error = "AudioRecord could not be initialised";
                }
                return false;
            }
            rate = r.getSampleRate();
            channels = r.getChannelCount();
            synchronized (lock) {
                pending = new float[Math.max(rate * channels, 1024)];
                pendingLen = 0;
            }
            record = r;
            running = true;
            r.startRecording();
            if (r.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                error = "Microphone is busy or unavailable";
                running = false;
                r.release();
                record = null;
                return false;
            }
            final AudioRecord rr = r;
            final int chunk = Math.max(256, rate * channels / 50);
            thread = new Thread(() -> readLoop(rr, chunk), "VfxRecorder");
            thread.start();
            return true;
        } catch (Throwable t) {
            error = "start failed: " + t;
            running = false;
            return false;
        }
    }

    private void readLoop(AudioRecord r, int chunk) {
        float[] tmp = new float[chunk];
        while (running) {
            int n = r.read(tmp, 0, tmp.length, AudioRecord.READ_BLOCKING);
            if (n < 0) {
                error = "AudioRecord.read error " + n;
                break;
            }
            if (n == 0) {
                continue;
            }
            synchronized (lock) {
                if (pendingLen + n > MAX_FLOATS) {
                    continue; // Godot side is not draining; drop instead of running out of memory
                }
                if (pendingLen + n > pending.length) {
                    pending = Arrays.copyOf(pending, Math.max(pending.length * 2, pendingLen + n));
                }
                System.arraycopy(tmp, 0, pending, pendingLen, n);
                pendingLen += n;
            }
        }
    }

    /** Returns everything captured since the last call (interleaved float32). */
    @UsedByGodot
    public float[] drain() {
        synchronized (lock) {
            float[] out = Arrays.copyOf(pending, pendingLen);
            pendingLen = 0;
            return out;
        }
    }

    @UsedByGodot
    public void stop() {
        running = false;
        Thread t = thread;
        thread = null;
        if (t != null) {
            try {
                t.join(500);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
        }
        AudioRecord r = record;
        record = null;
        if (r != null) {
            try {
                r.stop();
            } catch (Throwable ignored) {
            }
            r.release();
        }
    }

    @UsedByGodot
    public boolean isRecording() {
        return running;
    }

    @UsedByGodot
    public int getRate() {
        return rate;
    }

    @UsedByGodot
    public int getChannels() {
        return channels;
    }

    @UsedByGodot
    public String getError() {
        return error;
    }

    /**
     * Suggested default rate as "rate|basis". Order: built-in mic rate list (48000 preferred),
     * then the phone's native output rate, then 48000. It is a good guess, not a guarantee.
     */
    @UsedByGodot
    public String getDefaultRate() {
        try {
            Context ctx = getContext();
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                int best = 0;
                boolean has48 = false;
                for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_INPUTS)) {
                    if (d.getType() != AudioDeviceInfo.TYPE_BUILTIN_MIC) {
                        continue;
                    }
                    for (int r : d.getSampleRates()) {
                        if (r == 48000) {
                            has48 = true;
                        }
                        if (r > best && r <= 192000) {
                            best = r;
                        }
                    }
                }
                if (has48) {
                    return "48000|microphone list";
                }
                if (best > 0) {
                    return best + "|microphone list";
                }
                String out = am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE);
                if (out != null) {
                    int v = Integer.parseInt(out.trim());
                    if (v >= 8000 && v <= 192000) {
                        return v + "|phone output rate";
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return "48000|fallback";
    }

    /** Rates the system accepts for float recording (mono or stereo), comma separated, ascending. */
    @UsedByGodot
    public String getAcceptedRates() {
        StringBuilder sb = new StringBuilder();
        int[] rates = new int[] { 8000, 11025, 16000, 22050, 32000, 44100, 48000, 88200, 96000, 176400, 192000 };
        for (int rt : rates) {
            int a = AudioRecord.getMinBufferSize(rt, maskFor(1), AudioFormat.ENCODING_PCM_FLOAT);
            int b = AudioRecord.getMinBufferSize(rt, maskFor(2), AudioFormat.ENCODING_PCM_FLOAT);
            if (a > 0 || b > 0) {
                if (sb.length() > 0) {
                    sb.append(',');
                }
                sb.append(rt);
            }
        }
        return sb.toString();
    }

    /** Highest rate listed by the built-in microphone, or 0 when the phone gives no list. */
    @UsedByGodot
    public int getMicMaxRate() {
        int best = 0;
        try {
            AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_INPUTS)) {
                    if (d.getType() != AudioDeviceInfo.TYPE_BUILTIN_MIC) {
                        continue;
                    }
                    for (int r : d.getSampleRates()) {
                        if (r > best) {
                            best = r;
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return best;
    }

    /** Which rates the system accepts for float recording (this only means "accepted", the mic may be resampled by Android). */
    @UsedByGodot
    public String probe() {
        StringBuilder sb = new StringBuilder();
        int[] rates = new int[] { 8000, 16000, 22050, 32000, 44100, 48000, 88200, 96000, 176400, 192000 };
        for (int ch = 1; ch <= 2; ch++) {
            sb.append(ch == 1 ? "Mono:" : "Stereo:");
            for (int rt : rates) {
                int min = AudioRecord.getMinBufferSize(rt, maskFor(ch), AudioFormat.ENCODING_PCM_FLOAT);
                if (min > 0) {
                    sb.append(' ').append(rt);
                }
            }
            sb.append('\n');
        }
        try {
            Context ctx = getContext();
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                sb.append("Native output rate: ").append(am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)).append(" Hz\n");
                AudioDeviceInfo[] devs = am.getDevices(AudioManager.GET_DEVICES_INPUTS);
                for (AudioDeviceInfo d : devs) {
                    int[] sr = d.getSampleRates();
                    int[] chs = d.getChannelCounts();
                    sb.append("Input '").append(d.getProductName()).append("' type ").append(d.getType())
                            .append(" rates ").append(sr.length == 0 ? "any/unknown" : Arrays.toString(sr))
                            .append(" channels ").append(chs.length == 0 ? "any/unknown" : Arrays.toString(chs)).append('\n');
                }
            }
        } catch (Throwable t) {
            sb.append("info error: ").append(t).append('\n');
        }
        return sb.toString();
    }
}
