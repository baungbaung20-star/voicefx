# Voice FX Studio (Godot 4.7.2)

Step 1 - theme + main layout
Step 2 - WAV open/save, stereo waveform (L/R), zoom/scroll/playhead, Play/Pause/Stop/Loop
Step 3 - plain microphone Record (no effects) with live waveform + input level meter
Step 3c - export dialog: aligned grid layout, scrollable body, rates up to 192000 Hz + Custom; always-visible scrollbar
Step 3e - Open menu: "New (empty)" (uses the engine Mix Rate, same as Record; asks before discarding)
Step 3g - project.godot sets Mix Rate 48000; Record tab shows engine mix rate + mic rate before recording
Step 3h - Record tab diagnostics (engine mix rate, mic input rate, latency, driver, input device); project.godot adds driver/mix_rate.android=48000 override
Step 3b - Save as...: Audio Attributes sheet (presets, sample rate, Filter Attributes, format list),
          anti-alias low-pass when lowering the sample rate, u-Law / A-Law / float / 8-32 bit PCM

Controls (waveform):
- Tap = move playhead   - Drag = scroll   - Two-finger pinch = zoom
- Bottom strip = overview (drag to scroll)   - Zoom buttons under the waveform
- Desktop: mouse wheel = zoom, Shift+wheel = scroll

Open menu: "Open WAV file..." or "Load demo tone" (4 s stereo test tone, no file needed).
Supported WAV input: PCM 8/16/24/32-bit, float 32/64-bit, u-Law, A-Law (imports keep their own sample rate).
Save: any of those formats, mono/stereo, 8000-192000 Hz in the list or a Custom rate (1000-192000 Hz).

No class_name is used; scripts are linked with preload. UI is built in code.
Recording: press the red button. If a file is already open you choose Append / Insert at playhead / Replace.
Records mono at the device mix rate (usually 44100 or 48000 Hz). 20 minute safety limit.
Nothing is played through the speaker while recording (no feedback).

Roadmap: 4 Selection + Edit + Undo/Redo | 5 Offline effects | 6 Android export.

Step 3i - Native Android recorder (AudioRecord): choose rate (44100-192000), mono/stereo and source in the Record tab.
Step 3j - recorder labels renamed (Advanced / Standard), two more sources: Voice communication, Voice performance
Step 3k - single recorder (no Standard/Advanced choice), Custom rate field in the Record tab
Step 3l - Rate is chosen automatically from the phone (mic rate list, else output rate, else 48000); still changeable
Step 3m - rate list = rates the phone accepts (lowest first, "(upsampled)" above the mic maximum); Voice recognition / Voice communication auto-select 16000 Hz with a note
Step 3n - changing the Source sets the rate (Voice recognition/Voice communication 16000 Hz with a note, every other source 48000 Hz); a rate the user picks afterwards is what gets recorded
- Step 3p - Voice communication / Voice recognition always set the Rate to 16000 Hz (Custom if the phone does not list it).
- Step 3q - Rate list now scans down to 3000 Hz and includes the rates the microphone lists itself.
          Needs the Gradle APK built by GitHub Actions (see ci/ and .github/). In the normal phone-editor build the
          Record tab says "Native recorder: not in this build" and the Godot recorder (engine rate, mono) is used.
          android_plugin/java = Java plugin source, android_plugin/addon = editor export plugin, ci/build_apk.sh = CI build.
